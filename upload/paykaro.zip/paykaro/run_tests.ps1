Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "  LoomGuard Verification Suite - Running All Pytest Tests  " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

python -m pytest backend/tests -v

if ($LASTEXITCODE -eq 0) {
    Write-Host "[SUCCESS] All LoomGuard verification and reliability tests PASSED!" -ForegroundColor Green
} else {
    Write-Host "[FAIL] Test suite encountered errors." -ForegroundColor Red
}
