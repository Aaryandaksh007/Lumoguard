# LoomGuard — Pre-Publication Multimodal Brand Governance Platform
**Built for the Inkloom AI Brand Governance Challenge (300-Point Architecture)**

[![Python 3.11+](https://img.shields.io/badge/Python-3.11%2B-blue.svg)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.135.3-009688.svg)](https://fastapi.tiangolo.com)
[![React 19](https://img.shields.io/badge/React-19-61dafb.svg)](https://react.dev)
[![Tests: 13 Passed](https://img.shields.io/badge/Tests-13%20Passed%20(100%25)-brightgreen.svg)]()
[![Stage 1 Latency](https://img.shields.io/badge/Stage%201%20Latency-%3C50ms-success.svg)]()
[![WCAG 2.2](https://img.shields.io/badge/WCAG-2.2%20AA%2FAAA-purple.svg)](https://www.w3.org/TR/WCAG22/)

---

## 🚀 Overview

**LoomGuard** is an enterprise-grade pre-publication brand governance, factual claim-grounding, and collaborative proofing platform engineered around a **Two-Stage Hybrid Verification Architecture**. By coupling sub-50ms deterministic mathematical and lexical engines with retrieval-grounded semantic passes, LoomGuard intercepts brand violations across multimodal assets—Markdown blog posts, DOCX press releases, HTML landing pages, and promotional banners—before publication.

Rather than acting as a generic LLM wrapper that destructively rewrites creator work, LoomGuard treats brand guidelines as an executable **Brand Canon Specification**, delivering **Intent-Preserving Surgical Diffs** ($\ge 85\%$ intent preservation), an **Inkloom Context Trace Provenance Drawer**, and a mathematical **Guideline Ambiguity Score (GAS)** engine.

---

## 🏛️ The Six Verification Pillars

| Pillar | Engineering Architecture | Key Mathematical / Algorithmic Foundations |
| :--- | :--- | :--- |
| **1. Terminology & Lexicon** | In-memory Aho-Corasick automaton + syntactic grammar alignment | Sub-3ms regex boundary scanning, casing rules, allowed-context exceptions (`formerly known as...`), and indefinite article adjustment (*a* vs *an*). |
| **2. Tone & Messaging** | Deterministic linguistic analyzer + reference voice embedding | Paragraph-level Flesch-Kincaid Grade Level, Flesch Reading Ease, passive-voice ceilings, anti-cliché lexicon, and rhetorical headline exemption. |
| **3. Factual & Promotional Claims** | FActScore atomic decomposition + MiniCheck entailment | Decomposes compound claims into atomic facts $\{a_i\}$; checks entailment ($D_i \models a_i$) against `canon_facts`; deterministic numeric & date staleness verifier. |
| **4. Visual Geometry & Palette** | Deterministic color science & OpenCV computer vision | Full CIE CIEDE2000 ($\Delta E_{00}$) perceptual color difference, OpenCV logo aspect-ratio distortion ($|(w/h) - (w_{ref}/h_{ref})| > 0.02$), and 25% clear-space margin checks. |
| **5. WCAG 2.2 Accessibility** | W3C IEC 61966-2-1 luminance math + DOM AST parser | Exact unrounded contrast ratio: $\text{CR} = \frac{L_1 + 0.05}{L_2 + 0.05}$; APCA $L_c$ score; structural checks (alt text, heading jumps, ambiguous links). |
| **6. Confidentiality Protection** | Microsoft Presidio Reversible Proxy ("Sandwich Pattern") | Local PII recognition (PERSON, EMAIL, PHONE) + custom Brand Secret Deny-List (`Project Chronos`) $\to$ scrubbed prompt $\to$ longest-first de-anonymization. |

---

## 💡 The Two "Secret Weapons"

### Secret Weapon #1: The Guideline Ambiguity Score (GAS) Engine
LoomGuard mathematically distinguishes between habitual creator mistakes and unclear brand guidelines using telemetry logs:

$$\text{GAS}_r = \ln(1 + N_{\text{triggers}, r}) \cdot \left( 0.5 \frac{N_{\text{overrides}, r}}{N_{\text{triggers}, r}} + 0.3 \frac{N_{\text{disputes}, r}}{N_{\text{triggers}, r}} + 0.2 \min\left(1, \frac{\bar{T}_{\text{resolve}, r}}{T_{\max}}\right) \right)$$

- **Rule A (Clear Rule / Habitual Typo):** $\text{GAS} = 0.218 \implies$ Recommends 1-click workspace auto-fix and creator onboarding micro-tips.
- **Rule B (Unclear Brand Guideline):** $\text{GAS} = 2.217$ (10.2x higher friction) $\implies$ Triggers the **Canon Refiner Agent** to generate an unambiguous Brand Guideline Upgrade Diff with concrete "Do / Don't" examples.

### Secret Weapon #2: The Inkloom Context Trace Provenance Drawer
Clicking `[Trace Provenance]` on any finding opens a technical drawer displaying:
1. **Execution Provenance:** Local deterministic engine vs external AI service with model version and exact latency in milliseconds.
2. **Context Lineage:** Canon rule ID, approved fact chunk, and locked vs dynamic retrieval status.
3. **Confidentiality Shield Audit Proof:** Shows the live sanitized payload verifying that sensitive codenames (`{{SECRET_CODENAME_1}}`) were masked before transmission.

---

## 🏆 The Three Improvements (Round 2 & 3 Rubric — 35 Points)

1. **Improvement #1: The Auto-Contrast On-Brand Token Resolver:**
   When text contrast fails WCAG 2.2 (e.g. `#60A5FA` on `#F8FAFC` at 2.43:1), automatically searches `canon_visuals` for the approved brand swatch that achieves $\text{CR} \ge 4.5:1$ while minimizing CIEDE2000 perceptual distance ($\Delta E_{00}$) to the creator's color choice (swapping to `Brand-Blue-700 #1D4ED8` at 6.41:1 contrast).
2. **Improvement #2: The Guideline Ambiguity Score (GAS) & Canon Auto-Refiner:**
   Automated mathematical classification of rule friction with an agent that synthesizes human override justifications into an executable brand guideline update.
3. **Improvement #3: The Presidio Reversible Confidentiality Shield ("The Sandwich Pattern"):**
   Local entity detection, reversible opaque tokenization, external scrubbed LLM execution, and longest-placeholder-first de-anonymization to prevent prefix collisions.

---

## 🧪 Inkloom Concurrency & Reliability Test Suite

LoomGuard includes an integration test suite validating Inkloom's production standards:
- **25-Way Concurrent Race Condition Test (`test_concurrency_race.py`):** Fires 25 simultaneous transactions attempting to accept/override the same suggestion concurrently. Asserts that exactly ONE state transition commits without deadlocks or state corruption.
- **Deterministic Graceful Degradation Test (`test_degradation_fallback.py`):** Simulates external cloud LLM downtime; asserts that all Stage 1 deterministic checks execute in **< 50 milliseconds**.
- **Exact Mathematics Verification (`test_ciede2000_and_wcag.py`):** Verifies CIEDE2000 $\Delta E_{00} = 7.13$ drift and strict unrounded WCAG 2.2 luminance calculations.

To run the full test suite:
```powershell
python -m pytest backend/tests -v
```
*(All 13 tests pass in ~2.1 seconds)*

---

## 🏃 Quick Start Guide

### 1. Run the Backend API Server
```powershell
# From project root
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload
```
Swagger API docs available at: `http://127.0.0.1:8000/docs`

### 2. Run the Frontend Studio
```powershell
cd frontend
npm run dev
```
Open `http://localhost:5173` in your browser.

### 3. Experience the Live Demo
1. In the **Proofing Studio**, click **Load Official Inkloom Demo Packet** to load the launch campaign draft containing the 6 planted errors.
2. Click **Run Pre-Publication Audit** to see sub-50ms deterministic verification in action.
3. Click `[Trace Provenance]` on any card to inspect the Inkloom Context Trace Drawer and Presidio sanitized payload.
4. Click **Snap to #1D4ED8 (6.41:1)** on the visual proofing canvas to test the Auto-Contrast Token Resolver.
5. Navigate to the **Ambiguity Telemetry (GAS)** tab to see the 10.2x friction differential and trigger the **Canon Refiner Agent**!

