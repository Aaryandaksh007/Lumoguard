# LoomGuard — Team Roles & Individual Contribution Statements
**Inkloom AI Brand Governance Challenge (Rules 14, 15, 16)**

Each team member's primary architectural ownership, repository modules, and demonstrated technical capabilities are detailed below:

---

| Team Role & Member | Primary Architectural Ownership | Key Repository Files & Modules | Live Demo & Oral Defense Focus |
| :--- | :--- | :--- | :--- |
| **Member 1: Canon & Hybrid NLP Lead** | PostgreSQL + pgvector schema, Aho-Corasick terminology engine, FActScore/MiniCheck atomic claim decomposition and entailment pipeline, and numeric verification. | `backend/app/engines/terminology.py`<br>`backend/app/engines/claim_grounding.py`<br>`backend/app/db/models.py`<br>`backend/tests/test_claim_grounding.py` | Demonstrates atomic claim decomposition, 5 verification verdicts, and FActScore claim extraction against `canon_facts`. |
| **Member 2: Computer Vision & Accessibility Lead** | CIEDE2000 ($\Delta E_{00}$) color science, OpenCV SIFT/ORB logo aspect-ratio and clear-space geometry, WCAG 2.2 relative luminance + APCA calculator, and Auto-Contrast Token Resolver. | `backend/app/engines/visual_geometry.py`<br>`backend/app/engines/accessibility_wcag.py`<br>`backend/tests/test_ciede2000_and_wcag.py`<br>`frontend/src/components/VisualProofingCanvas.tsx` | Demonstrates exact IEC 61966-2-1 luminance math, CIEDE2000 $\Delta E_{00} = 7.13$ drift calculation, and the 1-click Auto-Contrast On-Brand Token Resolver. |
| **Member 3: Collaborative Workspace & Frontend Lead** | Next.js / Vite React UI, surgical diff editor, bidirectional comment-thread synchronization, visual bounding-box proofing canvas, and Guideline Ambiguity Score (GAS) dashboard. | `frontend/src/components/ProofingStudio.tsx`<br>`frontend/src/components/AmbiguityDashboard.tsx`<br>`frontend/src/App.tsx`<br>`backend/app/services/diff_engine.py` | Demonstrates inline green/red surgical diffs, intent preservation score calculations, and the interactive GAS 2x2 telemetry quadrant. |
| **Member 4: Privacy, Provenance & Reliability Lead** | Microsoft Presidio reversible PII/secret proxy, Inkloom Context Trace drawer, RBAC workflow state machine, and the 25-way concurrent PostgreSQL integration test suite. | `backend/app/engines/confidentiality_shield.py`<br>`frontend/src/components/ContextTraceDrawer.tsx`<br>`backend/app/services/ambiguity_service.py`<br>`backend/tests/test_concurrency_race.py` | Demonstrates Presidio longest-placeholder-first restoration, the [Trace Provenance] drawer, and the 25-way concurrent atomic transaction locking test. |

---

## Technical Defense Readiness
All members are prepared to answer deep questions regarding:
1. **Mathematical Accuracy:** Proofs of CIEDE2000 $\Delta E_{00}$, unrounded WCAG 2.2 luminance, and the Guideline Ambiguity Score formulation.
2. **Concurrency Safety:** How atomic CAS updates prevent race conditions across distributed review teams.
3. **Privacy Integrity:** Why the Presidio "Sandwich Pattern" guarantees that confidential codenames never leave the host machine.

