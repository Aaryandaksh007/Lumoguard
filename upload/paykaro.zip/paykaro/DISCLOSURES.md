# LoomGuard — Competition Disclosures & Submission Integrity
**Inkloom AI Brand Governance Challenge (Rules 5, 6, 7 & Integrity Mandates)**

This document explicitly details all boilerplate code, open-source dependencies, third-party services, and generative AI development tooling used in the creation and execution of **LoomGuard**.

---

## 1. Open-Source Libraries & Licenses

LoomGuard is engineered using enterprise open-source libraries under permissive licenses:

| Component / Library | Version | License | Primary Purpose in LoomGuard |
| :--- | :--- | :--- | :--- |
| **pyahocorasick** | 2.3.1 | BSD-3-Clause | Sub-3ms deterministic lexical scanning across Brand Canon forbidden & deprecated terms. |
| **Microsoft Presidio** (`presidio-analyzer`, `presidio-anonymizer`) | 2.2.366 | MIT | Local PII recognition and reversible tokenization for "The Sandwich Pattern" privacy proxy. |
| **OpenCV (`opencv-python`)** | 5.0.0.93 | Apache 2.0 | Logo aspect ratio distortion and 25% clear-space isolation margin verification. |
| **NumPy** | 2.4.6 | BSD-3-Clause | Exact W3C IEC 61966-2-1 linear luminance math and CIEDE2000 ($\Delta E_{00}$) color difference. |
| **FastAPI** | 0.135.3 | MIT | Asynchronous, typed backend orchestrator for parallel verification passes. |
| **Uvicorn** | 0.44.0 | BSD-3-Clause | High-performance ASGI web server. |
| **SQLAlchemy** | 2.0.50 | MIT | Relational ORM supporting ACID transactions and row-level concurrency protection. |
| **React** | 19.0.0 | MIT | Modern component workspace for the Multimodal Proofing Studio. |
| **Tailwind CSS** | 4.0.0 | MIT | Utility-first styling with custom dark-mode token palette. |
| **Lucide React** | 1.16.0 | ISC | Accessibility, system status, and provenance icons. |
| **Vite** | 6.x / 9.x | MIT | Sub-second frontend HMR build engine. |

---

## 2. Starter Templates & Boilerplate Code

- **Frontend Scaffolding:** Initialized using standard Vite React-TypeScript template (`npm create vite@latest frontend -- --template react-ts`). All application architecture, components (`ProofingStudio`, `AmbiguityDashboard`, `ContextTraceDrawer`, `VisualProofingCanvas`), and styles were developed natively.
- **Backend Architecture:** Built natively with Python FastAPI. Zero monolithic black-box starter repos were cloned or repurposed.

---

## 3. External Cloud Services & AI Models

LoomGuard implements a **Two-Stage Hybrid Verification Architecture**:
1. **Stage 1 (Local Deterministic):** Runs 100% locally on the host machine without external network dependencies (pyahocorasick, CIEDE2000, IEC 61966-2-1 luminance math, Presidio entity detection). Execution latency: **< 50 milliseconds**.
2. **Stage 2 (Grounded Semantic Entailment):**
   - **Cloud Mode:** Anthropic Claude 3.5 Sonnet / OpenAI GPT-4o for complex multimodal diff synthesis.
   - **Confidentiality Shield Airlock:** All prompts are scrubbed by Microsoft Presidio into opaque tokens (e.g. `{{SECRET_CODENAME_1}}`) before leaving the local machine.
   - **Air-Gapped Local Mode:** When the workspace "Air-Gapped Mode" lock is engaged, all outbound network requests are terminated and semantic passes route to on-premise Ollama instances (Llama-3.1-8B-Instruct).

---

## 4. AI Coding Assistants Used in Development

In compliance with Rule 6:
- **Assistant Tools:** Google DeepMind Advanced Agentic Coding Assistant (Antigravity).
- **Scope of Usage:** Architectural pair-programming, test case generation for 25-way concurrent race conditions, mathematical validation of CIEDE2000 formulas, and TypeScript component wiring.
- **Human Authorship:** System architecture, database schema, mathematical implementations, and prompt designs were conceived and guided by the submission team.

