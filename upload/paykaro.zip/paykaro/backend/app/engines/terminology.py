import re
import time
from typing import List, Dict, Any, Optional
import ahocorasick

class TerminologyEngine:
    def __init__(self, terms_data: Optional[List[Dict[str, Any]]] = None):
        self.automaton = ahocorasick.Automaton()
        self.rules_lookup = {}
        if terms_data:
            self.load_terms(terms_data)

    def load_terms(self, terms_data: List[Dict[str, Any]]):
        self.automaton = ahocorasick.Automaton()
        self.rules_lookup = {}
        for rule in terms_data:
            term = rule["surface_form"]
            # Store lower-case key in automaton for case-insensitive matching
            key = term.lower()
            self.automaton.add_word(key, (term, rule))
            self.rules_lookup[rule["term_id"]] = rule
        self.automaton.make_automaton()

    def audit_text(self, text: str) -> List[Dict[str, Any]]:
        t_start = time.perf_counter()
        findings = []
        text_lower = text.lower()

        for end_idx, (orig_term, rule) in self.automaton.iter(text_lower):
            start_idx = end_idx - len(orig_term) + 1
            matched_span = text[start_idx:end_idx + 1]

            # 1. Whole word boundary check to avoid partial word matches
            is_word_start = (start_idx == 0) or not text[start_idx - 1].isalnum()
            is_word_end = (end_idx + 1 == len(text)) or not text[end_idx + 1].isalnum()
            if not (is_word_start and is_word_end):
                continue

            # 2. Check case-sensitivity rule if required
            if rule.get("rule_type") == "CASE_SENSITIVE" and matched_span != orig_term:
                continue

            # 3. Check allowed context exception regex
            allowed_regex = rule.get("allowed_context_regex")
            if allowed_regex:
                # Look at context window around the match (e.g. 50 chars before and after)
                ctx_start = max(0, start_idx - 60)
                ctx_end = min(len(text), end_idx + 61)
                context_window = text[ctx_start:ctx_end]
                if re.search(allowed_regex, context_window, re.IGNORECASE):
                    # Exception allowed
                    continue

            # 4. Syntactic & Indefinite Article Pass (Stage 2 auto-grammar alignment)
            replacement = rule.get("replacement_token", "")
            preceding_context = text[max(0, start_idx - 10):start_idx]
            article_match = re.search(r"\b(a|an)\s+$", preceding_context, re.IGNORECASE)
            suggested_replacement = replacement
            applied_char_start = start_idx

            if article_match and replacement:
                article = article_match.group(1)
                article_start = max(0, start_idx - 10) + article_match.start(1)
                # Determine correct article for replacement
                first_letter = replacement.strip()[0].lower()
                needs_an = first_letter in "aeiou"
                correct_article = "an" if needs_an else "a"
                if article.isupper():
                    correct_article = correct_article.upper()
                elif article[0].isupper():
                    correct_article = correct_article.capitalize()

                if article.lower() != correct_article.lower():
                    # Extend diff to include article correction
                    applied_char_start = article_start
                    matched_span = text[applied_char_start:end_idx + 1]
                    suggested_replacement = f"{correct_article} {replacement}"

            latency_ms = (time.perf_counter() - t_start) * 1000.0

            findings.append({
                "pillar": "TERMINOLOGY",
                "rule_id": rule.get("term_id", "TERM-UNKNOWN"),
                "rule_type": rule.get("rule_type", "DEPRECATED"),
                "severity": "HIGH" if rule.get("rule_type") == "FORBIDDEN" else "MEDIUM",
                "original_span": matched_span,
                "char_start": applied_char_start,
                "char_end": end_idx + 1,
                "suggested_diff": suggested_replacement,
                "explanation": f"Rule {rule.get('term_id')}: '{matched_span}' violates terminology standard. {rule.get('rationale_citation', '')}",
                "provenance": {
                    "engine": "DETERMINISTIC_ENGINE_LOCAL",
                    "algorithm": "Aho-Corasick Automaton + Regex Boundary",
                    "citation": rule.get("rationale_citation", ""),
                    "latency_ms": round(latency_ms, 3),
                    "context_mode": "LOCKED_CANON_RULE"
                },
                "intent_preservation_score": 0.98
            })

        return findings

