import re
import time
from typing import List, Dict, Any

def count_syllables(word: str) -> int:
    word = word.lower().strip()
    if not word:
        return 0
    if len(word) <= 3:
        return 1
    # Remove trailing 'e', 'es', 'ed' if not preceded by certain consonants
    word = re.sub(r"(?:[^laeiouy]|ed|es|e)$", "", word)
    vowels = "aeiouy"
    count = 0
    prev_is_vowel = False
    for char in word:
        is_vowel = char in vowels
        if is_vowel and not prev_is_vowel:
            count += 1
        prev_is_vowel = is_vowel
    return max(1, count)

class VoiceToneEngine:
    def __init__(self, voice_spec: Dict[str, Any] = None):
        self.voice_spec = voice_spec or {
            "flesch_kincaid_min": 7.0,
            "flesch_kincaid_max": 13.0,
            "passive_voice_max_pct": 18.0,
            "forbidden_cliches": [
                "delve into", "testament to", "game-changer", "revolutionary paradigm",
                "harness the power of", "in today's fast-paced world", "cutting-edge innovation",
                "seamlessly integrate", "embark on a journey"
            ]
        }

    def analyze_readability(self, text: str) -> Dict[str, float]:
        sentences = [s.strip() for s in re.split(r"[.!?]+", text) if s.strip()]
        words = re.findall(r"\b[A-Za-z0-9'-]+\b", text)

        num_sentences = max(1, len(sentences))
        num_words = max(1, len(words))
        total_syllables = sum(count_syllables(w) for w in words)

        words_per_sentence = num_words / num_sentences
        syllables_per_word = total_syllables / num_words

        # Flesch-Kincaid Grade Level
        fk_grade = (0.39 * words_per_sentence) + (11.8 * syllables_per_word) - 15.59
        fk_grade = max(1.0, round(fk_grade, 2))

        # Flesch Reading Ease
        reading_ease = 206.835 - (1.015 * words_per_sentence) - (84.6 * syllables_per_word)
        reading_ease = max(0.0, min(100.0, round(reading_ease, 2)))

        # Passive voice detection
        passive_regex = r"\b(is|are|was|were|been|being|be|become|becomes|became)\s+([A-Za-z]+ed|written|seen|taken|done|proven|built|developed|made|processed)\b"
        passive_matches = list(re.finditer(passive_regex, text, re.IGNORECASE))
        passive_pct = round((len(passive_matches) / num_sentences) * 100.0, 1)

        return {
            "num_sentences": num_sentences,
            "num_words": num_words,
            "fk_grade": fk_grade,
            "reading_ease": reading_ease,
            "passive_matches_count": len(passive_matches),
            "passive_pct": passive_pct
        }

    def audit_text(self, text: str) -> List[Dict[str, Any]]:
        t_start = time.perf_counter()
        findings = []

        stats = self.analyze_readability(text)
        fk_min = self.voice_spec.get("flesch_kincaid_min", 7.0)
        fk_max = self.voice_spec.get("flesch_kincaid_max", 13.0)
        passive_max = self.voice_spec.get("passive_voice_max_pct", 18.0)

        # 1. Formulaic Clichés Detection
        cliches = self.voice_spec.get("forbidden_cliches", [])
        for cliche in cliches:
            for match in re.finditer(r"\b" + re.escape(cliche) + r"\b", text, re.IGNORECASE):
                latency_ms = (time.perf_counter() - t_start) * 1000.0
                findings.append({
                    "pillar": "VOICE",
                    "rule_id": "RULE-VOICE-CLICHE",
                    "severity": "MEDIUM",
                    "original_span": match.group(0),
                    "char_start": match.start(),
                    "char_end": match.end(),
                    "suggested_diff": "explore" if "delve" in cliche.lower() else "demonstration of",
                    "explanation": f"Overused AI cliché detected: '{match.group(0)}'. Brand voice requires grounded, authentic phrasing.",
                    "provenance": {
                        "engine": "DETERMINISTIC_ENGINE_LOCAL",
                        "algorithm": "Regex Cliché Lexicon Scanner",
                        "citation": "Brand Voice Spec §3.4: Anti-Formulaic LLM Clichés",
                        "latency_ms": round(latency_ms, 3),
                        "context_mode": "LOCKED_CANON_VOICE"
                    },
                    "intent_preservation_score": 0.95
                })

        # 2. Passive Voice Ceiling Check
        if stats["passive_pct"] > passive_max:
            latency_ms = (time.perf_counter() - t_start) * 1000.0
            findings.append({
                "pillar": "VOICE",
                "rule_id": "RULE-VOICE-PASSIVE",
                "severity": "LOW",
                "original_span": f"{stats['passive_pct']}% passive constructions",
                "char_start": 0,
                "char_end": min(len(text), 100),
                "suggested_diff": None,
                "explanation": f"Passive voice percentage ({stats['passive_pct']}%) exceeds brand ceiling ({passive_max}%). Prefer active subject-verb phrasing.",
                "provenance": {
                    "engine": "DETERMINISTIC_ENGINE_LOCAL",
                    "algorithm": "Part-of-Speech Heuristic Parser",
                    "citation": "Brand Voice Spec §2.1: Active Construction Mandate",
                    "latency_ms": round(latency_ms, 3),
                    "context_mode": "LOCKED_CANON_VOICE"
                },
                "intent_preservation_score": 1.0
            })

        # 3. Reading Grade Level Check (Exempt short rhetorical headlines)
        if stats["num_words"] > 40 and (stats["fk_grade"] < fk_min or stats["fk_grade"] > fk_max):
            latency_ms = (time.perf_counter() - t_start) * 1000.0
            findings.append({
                "pillar": "VOICE",
                "rule_id": "RULE-VOICE-READABILITY",
                "severity": "LOW",
                "original_span": f"Document Readability Grade {stats['fk_grade']}",
                "char_start": 0,
                "char_end": min(len(text), 100),
                "suggested_diff": None,
                "explanation": f"Flesch-Kincaid Grade Level {stats['fk_grade']} is outside the approved target range [{fk_min} - {fk_max}].",
                "provenance": {
                    "engine": "DETERMINISTIC_ENGINE_LOCAL",
                    "algorithm": "Flesch-Kincaid / Reading Ease Mathematical Formula",
                    "citation": "Brand Voice Spec §2.3: Readability Range",
                    "latency_ms": round(latency_ms, 3),
                    "context_mode": "LOCKED_CANON_VOICE"
                },
                "intent_preservation_score": 1.0
            })

        return findings

