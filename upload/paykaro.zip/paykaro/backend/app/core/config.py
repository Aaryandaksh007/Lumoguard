import os
from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    PROJECT_NAME: str = "LoomGuard"
    VERSION: str = "3.0.0"
    API_V1_STR: str = "/api/v1"
    
    # Database
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./loomguard.db")
    SYNC_DATABASE_URL: str = os.getenv("SYNC_DATABASE_URL", "sqlite:///./loomguard.db")
    
    # Privacy & Confidentiality Shield Mode
    # AIR_GAPPED_MODE: True blocks all external cloud calls and uses local-only deterministic + Ollama engines
    AIR_GAPPED_MODE: bool = os.getenv("AIR_GAPPED_MODE", "false").lower() == "true"
    
    # Presidio Confidence Calibration Thresholds (0.4 to 0.7 for optimal precision/recall)
    PRESIDIO_MIN_SCORE: float = 0.40
    
    # Semantic Intent Preservation Threshold
    INTENT_SIMILARITY_MIN: float = 0.85
    
    # SLA for Guideline Ambiguity Score (hours)
    GAS_MAX_HOURS_SLA: float = 48.0
    
    # WCAG 2.2 Thresholds
    WCAG_AA_NORMAL_TEXT_CONTRAST: float = 4.5
    WCAG_AA_LARGE_TEXT_CONTRAST: float = 3.0
    WCAG_AAA_TEXT_CONTRAST: float = 7.0
    
    # CIEDE2000 Thresholds
    CIEDE2000_NOTICEABLE_DIFF: float = 3.0
    
    # Logo Geometric Tolerances
    LOGO_ASPECT_RATIO_TOLERANCE: float = 0.02
    LOGO_CLEAR_SPACE_MIN_RATIO: float = 0.25  # 25% of logo height
    
    class Config:
        case_sensitive = True

settings = Settings()

