import difflib
import re
from typing import List, Dict, Any, Tuple

def compute_intent_preservation_score(orig_text: str, diff_text: str) -> float:
    """
    Computes lexical and semantic overlap between original and proposed replacement.
    Ensures intent is preserved (score >= 0.85).
    """
    if not orig_text or not diff_text:
        return 1.0

    orig_words = set(re.findall(r"\w+", orig_text.lower()))
    diff_words = set(re.findall(r"\w+", diff_text.lower()))

    if not orig_words or not diff_words:
        return 1.0

    intersection = orig_words.intersection(diff_words)
    union = orig_words.union(diff_words)
    jaccard = len(intersection) / len(union)

    # Sequence matcher ratio for word order preservation
    matcher = difflib.SequenceMatcher(None, orig_text.lower().split(), diff_text.lower().split())
    seq_ratio = matcher.ratio()

    # Blended Intent Preservation Score
    intent_score = 0.4 * jaccard + 0.6 * seq_ratio
    return round(max(0.70, min(1.0, intent_score)), 3)

def generate_inline_diff_chunks(orig_str: str, proposed_str: str) -> List[Dict[str, str]]:
    """
    Splits text into structured inline diff chunks for rich-text visualization:
    - 'equal': unchanged text
    - 'removed': deleted span (red strikethrough)
    - 'added': inserted span (green underline)
    """
    matcher = difflib.SequenceMatcher(None, orig_str, proposed_str)
    chunks = []

    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            chunks.append({"type": "equal", "text": orig_str[i1:i2]})
        elif tag == "delete":
            chunks.append({"type": "removed", "text": orig_str[i1:i2]})
        elif tag == "insert":
            chunks.append({"type": "added", "text": proposed_str[j1:j2]})
        elif tag == "replace":
            chunks.append({"type": "removed", "text": orig_str[i1:i2]})
            chunks.append({"type": "added", "text": proposed_str[j1:j2]})

    return chunks

