import time
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from backend.app.core.config import settings
from backend.app.db.seed_data import seed_database
from backend.app.routers import audit, canon, suggestions, ambiguity, confidentiality

app = FastAPI(
    title="LoomGuard API",
    description="Pre-Publication Brand Governance & Intent-Preserving Proofing Platform",
    version=settings.VERSION
)

# Enable CORS for frontend workspace
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def on_startup():
    # Ensure database is created and seeded with Inkloom AI Brand Canon
    seed_database()

# Include all module routers
app.include_router(audit.router, prefix="/api/v1")
app.include_router(canon.router, prefix="/api/v1")
app.include_router(suggestions.router, prefix="/api/v1")
app.include_router(ambiguity.router, prefix="/api/v1")
app.include_router(confidentiality.router, prefix="/api/v1")

@app.get("/")
def root():
    return {
        "system": "LoomGuard - Inkloom AI Brand Governance Engine",
        "version": settings.VERSION,
        "status": "OPERATIONAL",
        "air_gapped_mode": settings.AIR_GAPPED_MODE,
        "documentation": "/docs",
        "three_improvements": [
            "1. Auto-Contrast On-Brand Token Resolver (WCAG 2.2 + CIEDE2000 ΔE00)",
            "2. Guideline Ambiguity Score (GAS) & Canon Auto-Refiner Agent",
            "3. Microsoft Presidio Reversible Confidentiality Shield ('The Sandwich Pattern')"
        ]
    }

@app.get("/health")
def health_check():
    return {"status": "HEALTHY", "timestamp": time.time()}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.app.main:app", host="0.0.0.0", port=8000, reload=True)

