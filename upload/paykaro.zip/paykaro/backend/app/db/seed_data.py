import json
from backend.app.db.database import SessionLocal, engine, Base
from backend.app.db.models import (
    CanonTerm, CanonVoice, CanonFact, CanonVisual, CanonLogo, GuidelineTelemetry
)

def seed_database():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    # 1. Seed Canon Terms
    if db.query(CanonTerm).count() == 0:
        terms = [
            CanonTerm(
                term_id="TERM-001",
                surface_form="InkLoom",
                rule_type="DEPRECATED",
                replacement_token="Inkloom AI",
                allowed_context_regex=r"(?i)formerly known as InkLoom",
                rationale_citation="Brand Canon §1.2: Official brand mark is 'Inkloom AI' with standard title casing."
            ),
            CanonTerm(
                term_id="TERM-002",
                surface_form="InkLoom Studio",
                rule_type="DEPRECATED",
                replacement_token="Inkloom Manuscript Studio",
                allowed_context_regex=None,
                rationale_citation="Product Taxonomy v2.4: 'InkLoom Studio' was renamed to 'Inkloom Manuscript Studio' in Q1 2026."
            ),
            CanonTerm(
                term_id="TERM-003",
                surface_form="AI magic",
                rule_type="FORBIDDEN",
                replacement_token="intelligent verification",
                allowed_context_regex=None,
                rationale_citation="Brand Canon §3.1: Prohibits mystical AI jargon; use grounded technical descriptions."
            ),
            CanonTerm(
                term_id="TERM-004",
                surface_form="delve into",
                rule_type="FORBIDDEN",
                replacement_token="examine",
                allowed_context_regex=None,
                rationale_citation="Editorial Style Guide §4.2: Banned formulaic LLM clichés."
            ),
            CanonTerm(
                term_id="TERM-005",
                surface_form="testament to",
                rule_type="FORBIDDEN",
                replacement_token="demonstration of",
                allowed_context_regex=None,
                rationale_citation="Editorial Style Guide §4.2: Banned formulaic LLM clichés."
            ),
        ]
        db.add_all(terms)

    # 2. Seed Canon Voice
    if db.query(CanonVoice).count() == 0:
        voice = CanonVoice(
            voice_id="VOICE-001",
            persona_name="Engineering-Grade Authoritative & Grounded",
            flesch_kincaid_min=8.0,
            flesch_kincaid_max=12.0,
            passive_voice_max_pct=15.0,
            approved_samples_json=json.dumps([
                "Inkloom AI couples deterministic verification with retrieval-grounded semantic passes to guarantee brand integrity.",
                "Every proposal is presented as a surgical diff requiring explicit human authorization."
            ]),
            forbidden_cliches_json=json.dumps([
                "delve into", "testament to", "game-changer", "revolutionary paradigm", 
                "harness the power of", "in today's fast-paced world"
            ])
        )
        db.add(voice)

    # 3. Seed Canon Facts (Atomic Fact & Claims Ledger)
    if db.query(CanonFact).count() == 0:
        facts = [
            CanonFact(
                fact_id="FACT-001",
                claim_assertion="Inkloom AI verification executes Stage 1 deterministic passes in under 50 milliseconds.",
                atomic_breakdown_json=json.dumps([
                    "Inkloom AI features a two-stage pipeline",
                    "Stage 1 deterministic passes run in sub-50ms"
                ]),
                status="CANONICAL",
                effective_date="2026-01-01",
                expiration_date="2027-01-01",
                evidence_doc_url="https://inkloom.ai/benchmarks/engine-v3",
                required_disclaimer_text=None
            ),
            CanonFact(
                fact_id="FACT-002",
                claim_assertion="LoomGuard Enterprise plan is priced at $79 per seat per month billed annually.",
                atomic_breakdown_json=json.dumps([
                    "Enterprise tier price is $79/user/month",
                    "Billing cycle is annual"
                ]),
                status="CANONICAL",
                effective_date="2026-01-15",
                expiration_date="2027-01-15",
                evidence_doc_url="https://inkloom.ai/pricing/enterprise-2026",
                required_disclaimer_text=None
            ),
            CanonFact(
                fact_id="FACT-003",
                claim_assertion="LoomGuard Enterprise plan is priced at $49 per seat per month.",
                atomic_breakdown_json=json.dumps([
                    "Legacy tier price was $49/user/month"
                ]),
                status="SUPERSEDED",
                effective_date="2024-01-01",
                expiration_date="2025-12-31",
                evidence_doc_url="https://inkloom.ai/archive/pricing-2024",
                required_disclaimer_text=None,
                superseded_by_fact_id="FACT-002"
            ),
            CanonFact(
                fact_id="FACT-004",
                claim_assertion="LoomGuard provides real-time print dieline checking and CMYK spot-color separation.",
                atomic_breakdown_json=json.dumps([
                    "Print dieline automation",
                    "CMYK color separation"
                ]),
                status="ROADMAP_ASPIRATIONAL",
                effective_date="2026-10-01",
                expiration_date="2027-12-31",
                evidence_doc_url="https://inkloom.ai/roadmap/h2-2026",
                required_disclaimer_text=None
            ),
            CanonFact(
                fact_id="FACT-005",
                claim_assertion="LoomGuard assists compliance teams by flagging regulatory and FTC claims, but does not substitute for certified legal counsel.",
                atomic_breakdown_json=json.dumps([
                    "LoomGuard assists compliance workflows",
                    "LoomGuard is not a human attorney substitute"
                ]),
                status="CANONICAL",
                effective_date="2026-01-01",
                expiration_date="2027-01-01",
                evidence_doc_url="https://inkloom.ai/legal/compliance-boundaries",
                required_disclaimer_text="Notice: LoomGuard is an assistive brand governance system and does not constitute certified legal counsel or formal statutory indemnification."
            ),
        ]
        db.add_all(facts)

    # 4. Seed Canon Visuals (Design Tokens & Color Swatches)
    if db.query(CanonVisual).count() == 0:
        swatches = [
            # Approved Canon Baseline: Brand-Blue-700 (#1D4ED8)
            # sRGB(29, 78, 216), CIE L*=37.5, a*=25.6, b*=-69.2, WCAG relative luminance=0.088
            CanonVisual(
                token_name="Brand-Blue-700",
                hex_value="#1D4ED8",
                r=29, g=78, b=216,
                cie_l=37.5, cie_a=25.6, cie_b=-69.2,
                wcag_luminance=0.088,
                role="PRIMARY",
                is_brand_core=True
            ),
            # Brand Deep Dark: #0F172A
            CanonVisual(
                token_name="Brand-Slate-900",
                hex_value="#0F172A",
                r=15, g=23, b=42,
                cie_l=8.5, cie_a=-1.2, cie_b=-9.8,
                wcag_luminance=0.011,
                role="TEXT",
                is_brand_core=True
            ),
            # Surface Light: #F8FAFC
            CanonVisual(
                token_name="Brand-Slate-50",
                hex_value="#F8FAFC",
                r=248, g=250, b=252,
                cie_l=98.1, cie_a=-0.4, cie_b=-1.1,
                wcag_luminance=0.957,
                role="SURFACE",
                is_brand_core=True
            ),
            # Clean White: #FFFFFF
            CanonVisual(
                token_name="Brand-White",
                hex_value="#FFFFFF",
                r=255, g=255, b=255,
                cie_l=100.0, cie_a=0.0, cie_b=0.0,
                wcag_luminance=1.000,
                role="SURFACE",
                is_brand_core=True
            ),
            # Accent Cyan: #0284C7
            CanonVisual(
                token_name="Brand-Sky-600",
                hex_value="#0284C7",
                r=2, g=132, b=199,
                cie_l=53.4, cie_a=-14.2, cie_b=-42.3,
                wcag_luminance=0.208,
                role="ACCENT",
                is_brand_core=True
            ),
        ]
        db.add_all(swatches)

    # 5. Seed Canon Logos
    if db.query(CanonLogo).count() == 0:
        logo = CanonLogo(
            logo_id="LOGO-001",
            asset_name="Inkloom AI Canonical Master Mark",
            canonical_width=200.0,
            canonical_height=50.0,
            aspect_ratio=4.00,  # 200 / 50 = 4.0
            clear_space_ratio=0.25  # 25% clear space on all sides
        )
        db.add(logo)

    # 6. Seed Guideline Ambiguity Telemetry (Rule A vs Rule B from Problem Statement Section 5.2)
    if db.query(GuidelineTelemetry).count() == 0:
        telemetry = [
            GuidelineTelemetry(
                rule_id="RULE-TERM-001",
                rule_name="Standard Mark Casing (Inkloom AI, never InkLoom)",
                pillar="TERMINOLOGY",
                triggers_count=40,
                overrides_count=3,
                disputes_count=2,
                mean_resolution_hours=1.5,
                gas_score=0.218,
                classification="HABITUAL_MISTAKE"
            ),
            GuidelineTelemetry(
                rule_id="RULE-VOICE-002",
                rule_name="Bold Challenger Tone with Humble Understatement",
                pillar="VOICE",
                triggers_count=35,
                overrides_count=22,
                disputes_count=18,
                mean_resolution_hours=36.0,
                gas_score=2.217,
                classification="UNCLEAR_GUIDELINE"
            ),
            GuidelineTelemetry(
                rule_id="RULE-FACT-002",
                rule_name="Current Enterprise Pricing Tier Substantiation",
                pillar="FACT_CLAIM",
                triggers_count=28,
                overrides_count=4,
                disputes_count=3,
                mean_resolution_hours=2.1,
                gas_score=0.342,
                classification="HABITUAL_MISTAKE"
            ),
            GuidelineTelemetry(
                rule_id="RULE-VIS-003",
                rule_name="Primary Palette Consistency (CIEDE2000 ΔE00 < 3.0)",
                pillar="VISUAL_GEOMETRY",
                triggers_count=19,
                overrides_count=2,
                disputes_count=1,
                mean_resolution_hours=0.8,
                gas_score=0.185,
                classification="HABITUAL_MISTAKE"
            ),
            GuidelineTelemetry(
                rule_id="RULE-WCAG-001",
                rule_name="Strict WCAG 2.2 AA Contrast Ratio (≥ 4.5:1)",
                pillar="ACCESSIBILITY_WCAG",
                triggers_count=24,
                overrides_count=3,
                disputes_count=2,
                mean_resolution_hours=1.2,
                gas_score=0.245,
                classification="HABITUAL_MISTAKE"
            )
        ]
        db.add_all(telemetry)

    db.commit()
    db.close()

if __name__ == "__main__":
    seed_database()
    print("LoomGuard Database Seeded Successfully.")

