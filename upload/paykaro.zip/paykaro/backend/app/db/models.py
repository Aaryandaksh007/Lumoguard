import datetime
from sqlalchemy import Column, Integer, String, Float, Text, Boolean, DateTime, ForeignKey, Index
from sqlalchemy.orm import relationship
from backend.app.db.database import Base

class CanonTerm(Base):
    __tablename__ = "canon_terms"

    id = Column(Integer, primary_key=True, index=True)
    term_id = Column(String(64), unique=True, index=True, nullable=False)
    surface_form = Column(String(255), index=True, nullable=False)
    rule_type = Column(String(32), nullable=False)  # FORBIDDEN, DEPRECATED, PREFERRED, CASE_SENSITIVE
    replacement_token = Column(String(255), nullable=True)
    allowed_context_regex = Column(String(512), nullable=True)  # Regex where exception is allowed
    rationale_citation = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class CanonVoice(Base):
    __tablename__ = "canon_voice"

    id = Column(Integer, primary_key=True, index=True)
    voice_id = Column(String(64), unique=True, index=True, nullable=False)
    persona_name = Column(String(128), nullable=False)
    flesch_kincaid_min = Column(Float, default=7.0)
    flesch_kincaid_max = Column(Float, default=12.0)
    passive_voice_max_pct = Column(Float, default=15.0)
    approved_samples_json = Column(Text, nullable=True)
    forbidden_cliches_json = Column(Text, nullable=True)

class CanonFact(Base):
    __tablename__ = "canon_facts"

    id = Column(Integer, primary_key=True, index=True)
    fact_id = Column(String(64), unique=True, index=True, nullable=False)
    claim_assertion = Column(Text, nullable=False)
    atomic_breakdown_json = Column(Text, nullable=True)
    status = Column(String(32), nullable=False)  # CANONICAL, ROADMAP_ASPIRATIONAL, SUPERSEDED
    effective_date = Column(String(32), nullable=True)
    expiration_date = Column(String(32), nullable=True)
    evidence_doc_url = Column(String(512), nullable=True)
    required_disclaimer_text = Column(Text, nullable=True)
    superseded_by_fact_id = Column(String(64), nullable=True)

class CanonVisual(Base):
    __tablename__ = "canon_visuals"

    id = Column(Integer, primary_key=True, index=True)
    token_name = Column(String(64), unique=True, index=True, nullable=False)
    hex_value = Column(String(16), nullable=False)
    r = Column(Integer, nullable=False)
    g = Column(Integer, nullable=False)
    b = Column(Integer, nullable=False)
    cie_l = Column(Float, nullable=False)
    cie_a = Column(Float, nullable=False)
    cie_b = Column(Float, nullable=False)
    wcag_luminance = Column(Float, nullable=False)
    role = Column(String(32), nullable=False)  # PRIMARY, ACCENT, SURFACE, TEXT
    is_brand_core = Column(Boolean, default=True)

class CanonLogo(Base):
    __tablename__ = "canon_logos"

    id = Column(Integer, primary_key=True, index=True)
    logo_id = Column(String(64), unique=True, index=True, nullable=False)
    asset_name = Column(String(128), nullable=False)
    canonical_width = Column(Float, nullable=False)
    canonical_height = Column(Float, nullable=False)
    aspect_ratio = Column(Float, nullable=False)  # w / h
    clear_space_ratio = Column(Float, default=0.25)  # 25% of height

class AssetAudit(Base):
    __tablename__ = "asset_audits"

    id = Column(Integer, primary_key=True, index=True)
    audit_id = Column(String(64), unique=True, index=True, nullable=False)
    title = Column(String(255), nullable=False)
    asset_type = Column(String(32), nullable=False)  # MARKDOWN, DOCX, HTML, PDF, BANNER_IMAGE
    original_content = Column(Text, nullable=False)
    scrubbed_content = Column(Text, nullable=True)
    status = Column(String(32), default="PREFLIGHT_CHECKED")  # DRAFT, PREFLIGHT_CHECKED, IN_REVIEW, CHANGES_REQUESTED, APPROVED_FOR_PUBLISH
    stage1_latency_ms = Column(Float, default=0.0)
    stage2_latency_ms = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    findings = relationship("AuditFinding", back_populates="audit", cascade="all, delete-orphan")

class AuditFinding(Base):
    __tablename__ = "audit_findings"

    id = Column(Integer, primary_key=True, index=True)
    finding_id = Column(String(64), unique=True, index=True, nullable=False)
    audit_id = Column(String(64), ForeignKey("asset_audits.audit_id"), nullable=False)
    pillar = Column(String(64), nullable=False)  # TERMINOLOGY, VOICE, FACT_CLAIM, VISUAL_GEOMETRY, ACCESSIBILITY_WCAG, CONFIDENTIALITY
    rule_id = Column(String(64), index=True, nullable=False)
    severity = Column(String(16), nullable=False)  # CRITICAL, HIGH, MEDIUM, LOW, INFO
    original_span = Column(Text, nullable=False)
    char_start = Column(Integer, default=-1)
    char_end = Column(Integer, default=-1)
    suggested_diff = Column(Text, nullable=True)
    verdict = Column(String(64), nullable=True)
    explanation = Column(Text, nullable=False)
    provenance_json = Column(Text, nullable=True, default="{}")  # Context Trace Data
    status = Column(String(32), default="PENDING")  # PENDING, ACCEPTED, REJECTED, OVERRIDDEN
    intent_preservation_score = Column(Float, default=1.0)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    audit = relationship("AssetAudit", back_populates="findings")
    reviews = relationship("SuggestionReview", back_populates="finding", cascade="all, delete-orphan")

class SuggestionReview(Base):
    __tablename__ = "suggestion_reviews"

    id = Column(Integer, primary_key=True, index=True)
    review_id = Column(String(64), unique=True, index=True, nullable=False)
    finding_id = Column(String(64), ForeignKey("audit_findings.finding_id"), nullable=False)
    action = Column(String(32), nullable=False)  # ACCEPT, REJECT, OVERRIDE
    actor_role = Column(String(64), nullable=False)  # CREATOR, BRAND_MANAGER, LEGAL_COMPLIANCE, GOVERNANCE_ADMIN
    override_reason = Column(String(64), nullable=True)  # INTENTIONAL_STYLE, UNCLEAR_GUIDELINE, APPROVED_EXCEPTION
    comment_thread_json = Column(Text, nullable=True)
    comments_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    resolved_at = Column(DateTime, nullable=True)

    finding = relationship("AuditFinding", back_populates="reviews")

class GuidelineTelemetry(Base):
    __tablename__ = "guideline_telemetry"

    id = Column(Integer, primary_key=True, index=True)
    rule_id = Column(String(64), unique=True, index=True, nullable=False)
    rule_name = Column(String(255), nullable=False)
    pillar = Column(String(64), nullable=False)
    triggers_count = Column(Integer, default=0)
    overrides_count = Column(Integer, default=0)
    disputes_count = Column(Integer, default=0)
    mean_resolution_hours = Column(Float, default=0.0)
    gas_score = Column(Float, default=0.0)
    classification = Column(String(64), default="HABITUAL_MISTAKE")  # HABITUAL_MISTAKE vs UNCLEAR_GUIDELINE
    updated_at = Column(DateTime, default=datetime.datetime.utcnow)

class AuditLogEntry(Base):
    __tablename__ = "audit_log_entries"

    id = Column(Integer, primary_key=True, index=True)
    log_id = Column(String(64), unique=True, index=True, nullable=False)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    action = Column(String(64), nullable=False)
    actor = Column(String(64), nullable=False)
    details_json = Column(Text, nullable=True)
    presidio_scrubbed_payload = Column(Text, nullable=True)
