from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, Any, List

from backend.app.db.database import get_db
from backend.app.db.models import CanonTerm, CanonVoice, CanonFact, CanonVisual, CanonLogo
from backend.app.services.orchestrator import VerificationOrchestrator
from backend.app.core.config import settings

router = APIRouter(prefix="/audit", tags=["Pre-Publication Audit"])

class AuditRequest(BaseModel):
    title: str = "Product Launch Campaign Packet"
    asset_type: str = "MARKDOWN"  # MARKDOWN, DOCX, HTML, PDF, BANNER_IMAGE
    content: str
    visual_meta: Optional[Dict[str, Any]] = None
    is_air_gapped: Optional[bool] = False

def get_orchestrator(db) -> VerificationOrchestrator:
    terms = [
        {
            "term_id": t.term_id,
            "surface_form": t.surface_form,
            "rule_type": t.rule_type,
            "replacement_token": t.replacement_token,
            "allowed_context_regex": t.allowed_context_regex,
            "rationale_citation": t.rationale_citation
        }
        for t in db.query(CanonTerm).all()
    ]

    facts = [
        {
            "fact_id": f.fact_id,
            "claim_assertion": f.claim_assertion,
            "status": f.status,
            "evidence_doc_url": f.evidence_doc_url,
            "required_disclaimer_text": f.required_disclaimer_text
        }
        for f in db.query(CanonFact).all()
    ]

    visuals = [
        {
            "token_name": v.token_name,
            "hex": v.hex_value,
            "role": v.role,
            "wcag_luminance": v.wcag_luminance
        }
        for v in db.query(CanonVisual).all()
    ]

    logo = db.query(CanonLogo).first()
    logo_rules = {
        "canonical_aspect_ratio": logo.aspect_ratio if logo else 4.0,
        "aspect_ratio_tolerance": settings.LOGO_ASPECT_RATIO_TOLERANCE,
        "min_clear_space_ratio": logo.clear_space_ratio if logo else 0.25
    }

    return VerificationOrchestrator(
        terms_data=terms,
        facts_data=facts,
        visual_tokens=visuals,
        logo_rules=logo_rules,
        confidential_codenames=["Project Chronos", "Project Hyperion", "Project Titan"]
    )

@router.post("/preflight")
def run_preflight_audit(payload: AuditRequest, db=Depends(get_db)):
    orchestrator = get_orchestrator(db)
    result = orchestrator.run_preflight_audit(
        title=payload.title,
        content=payload.content,
        asset_type=payload.asset_type,
        visual_meta=payload.visual_meta,
        is_air_gapped=payload.is_air_gapped or settings.AIR_GAPPED_MODE
    )
    return result

@router.get("/demo-packet")
def get_demo_campaign_packet():
    """
    Returns the official Inkloom AI Product Launch Campaign Packet containing
    the 6 planted pre-publication errors from Blueprint Section 7.3:
    1. Deprecated product name ("InkLoom Studio")
    2. Unsubstantiated promotional claim ("replaces your entire legal team with 100% accuracy")
    3. Secret project codename ("Project Chronos")
    4. Off-brand banner color (#2563EB with ΔE00 = 7.13 drift)
    5. Squashed logo (aspect ratio 2.4 vs canonical 4.0) with encroaching text (within 4px)
    6. Low contrast text (#60A5FA on #F8FAFC, CR = 2.43:1 failing WCAG AA)
    """
    sample_text = (
        "# Announcing InkLoom Studio: The Next Era of Brand Governance\n\n"
        "Today we are thrilled to unveil InkLoom Studio, our enterprise publication platform. "
        "Built under the confidential initiative Project Chronos, our new engine replaces your entire "
        "legal team with 100% accuracy, eliminating every compliance bottleneck overnight.\n\n"
        "Inkloom AI verification executes Stage 1 deterministic passes in under 50 milliseconds. "
        "The Enterprise plan is available starting today at $49 per user monthly billed annually. "
        "Delve into our documentation to harness the power of seamless brand compliance.\n\n"
        "<div class=\"cta-banner\">\n"
        "  <p>Learn more about our governance architecture: <a href=\"#\">click here</a></p>\n"
        "  <img src=\"brand_mark.png\" alt=\"image\" />\n"
        "</div>"
    )

    sample_visual_meta = {
        "asset_name": "Hero_Promotional_Banner_Q1.png",
        "dimensions": {"width": 1200, "height": 630},
        "extracted_colors": [
            {"name": "Background", "hex": "#F8FAFC"},
            {"name": "Primary Banner Accent", "hex": "#2563EB"},  # Near-miss Tailwind blue with ΔE00=7.13 drift from #1D4ED8
        ],
        "color_pairs": [
            {
                "fg": "#60A5FA",  # Light blue on light slate: 2.43:1 contrast ratio (FAILS WCAG AA < 4.5:1)
                "bg": "#F8FAFC",
                "element_name": "Hero Subtitle Text",
                "is_large": False
            }
        ],
        "logo_box": {
            "width": 120.0,
            "height": 50.0,  # Aspect ratio 120/50 = 2.40 (canonical is 4.00, diff = 1.60 > 0.02)
            "adjacent_text_dist": 4.5  # Adjacent text within 4.5px (minimum clear space is 25% of 50px = 12.5px)
        }
    }

    return {
        "title": "Inkloom Enterprise Launch Packet (Multimodal)",
        "asset_type": "MARKDOWN",
        "content": sample_text,
        "visual_meta": sample_visual_meta,
        "planted_errors_summary": [
            "Pillar 1 Terminology: Deprecated 'InkLoom Studio' violates Taxonomy v2.4",
            "Pillar 2 Voice: Banned LLM cliché 'delve into' and formulaic phrasing",
            "Pillar 3 Claims: Unsubstantiated 'replaces your entire legal team with 100% accuracy' + outdated '$49' pricing tier",
            "Pillar 4 Visual Geometry: Off-brand #2563EB (ΔE00 = 7.13) + distorted logo aspect ratio (2.40:1) with 4.5px text intrusion",
            "Pillar 5 Accessibility: Light blue #60A5FA on #F8FAFC (CR 2.43:1 fails WCAG AA 4.5:1) + missing img alt text + ambiguous 'click here' link",
            "Pillar 6 Confidentiality: Unannounced secret codename 'Project Chronos' detected"
        ]
    }

