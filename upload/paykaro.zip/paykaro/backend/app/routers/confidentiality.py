from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional, List

from backend.app.engines.confidentiality_shield import ConfidentialityShieldEngine
from backend.app.core.config import settings

router = APIRouter(prefix="/confidentiality", tags=["Presidio Confidentiality & Privacy Shield"])

shield = ConfidentialityShieldEngine()

class InspectPayloadRequest(BaseModel):
    raw_text: str = (
        "Internal brief: Project Chronos is scheduled for Q3 announcement by Sarah Connor (sarah@inkloom.ai). "
        "Project Chronos will deliver 10x faster verification."
    )

class ToggleLockRequest(BaseModel):
    air_gapped: bool

@router.get("/status")
def get_privacy_status():
    return {
        "air_gapped_mode": settings.AIR_GAPPED_MODE,
        "shield_provider": "Microsoft Presidio v2.2 + Custom Brand Secret Recognizer",
        "supported_entities": ["SECRET_CODENAME", "PERSON", "EMAIL_ADDRESS", "PHONE_NUMBER"],
        "deny_list_codenames": shield.confidential_codenames,
        "de_anonymization_strategy": "LONGEST_PLACEHOLDER_FIRST"
    }

@router.post("/toggle-privacy-lock")
def toggle_privacy_lock(payload: ToggleLockRequest):
    settings.AIR_GAPPED_MODE = payload.air_gapped
    return {
        "status": "SUCCESS",
        "air_gapped_mode": settings.AIR_GAPPED_MODE,
        "message": (
            "Local-First Privacy Lock ACTIVE: All outbound external cloud calls blocked. Using on-premise heuristic and Ollama models."
            if settings.AIR_GAPPED_MODE else
            "Presidio Reversible Proxy ACTIVE: Outbound calls permitted through confidential PII scrub and longest-first de-anonymization."
        )
    }

@router.post("/inspect-sandwich")
def inspect_sandwich_pattern(payload: InspectPayloadRequest):
    """
    Improvement #3 Live Demonstration:
    Walks through the 3-step Sandwich Pattern:
    1. Pre-flight entity detection
    2. Tokenized scrubbed prompt payload
    3. Longest-first restored output
    """
    raw_text = payload.raw_text

    # Step 1 & 2: Local detection and reversible tokenization
    scrubbed_text, token_map, entities = shield.redact_and_tokenize(raw_text)

    # Step 3: Simulated external LLM analysis returning text with placeholders intact
    simulated_llm_output = (
        f"External LLM Critique: We evaluated '{scrubbed_text}'. "
        "The proposed messaging aligns with brand standards, but check tone consistency."
    )

    # Step 4: Longest-first de-anonymization
    restored_output = shield.de_anonymize(simulated_llm_output, token_map)

    return {
        "step_1_raw_creator_input": raw_text,
        "step_2_detected_entities": entities,
        "step_3_scrubbed_payload_sent_to_llm": scrubbed_text,
        "session_token_map": token_map,
        "step_4_external_llm_received_response": simulated_llm_output,
        "step_5_restored_clean_output": restored_output,
        "privacy_guarantee": "Zero sensitive codenames or unreleased metrics leave the local host boundary."
    }

