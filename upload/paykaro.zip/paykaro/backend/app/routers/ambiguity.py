from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import List, Optional

from backend.app.db.database import get_db
from backend.app.db.models import GuidelineTelemetry
from backend.app.services.ambiguity_service import calculate_guideline_ambiguity_score, CanonRefinerAgent

router = APIRouter(prefix="/ambiguity", tags=["Guideline Ambiguity Telemetry (GAS)"])

class CanonRefineRequest(BaseModel):
    rule_id: str = "RULE-VOICE-002"

@router.get("/telemetry")
def get_ambiguity_telemetry(db=Depends(get_db)):
    """
    Secret Weapon #1: Returns live Guideline Ambiguity Scores.
    Mathematically distinguishes between Habitual Creator Typos vs. Unclear Brand Guidelines.
    """
    records = db.query(GuidelineTelemetry).all()
    results = []

    for r in records:
        analysis = calculate_guideline_ambiguity_score(
            triggers=r.triggers_count,
            overrides=r.overrides_count,
            disputes=r.disputes_count,
            mean_resolution_hours=r.mean_resolution_hours
        )
        results.append({
            "rule_id": r.rule_id,
            "rule_name": r.rule_name,
            "pillar": r.pillar,
            "triggers_count": r.triggers_count,
            "overrides_count": r.overrides_count,
            "override_rate_pct": analysis["override_rate"],
            "disputes_count": r.disputes_count,
            "dispute_rate_pct": analysis["dispute_rate"],
            "mean_resolution_hours": analysis["mean_resolution_hours"],
            "gas_score": analysis["gas_score"],
            "classification": analysis["classification"],
            "recommendation": analysis["recommendation"]
        })

    # Sort so highest ambiguity rules appear first
    results.sort(key=lambda x: x["gas_score"], reverse=True)

    summary = {
        "total_rules_monitored": len(results),
        "unclear_guidelines_count": sum(1 for r in results if r["classification"] == "UNCLEAR_GUIDELINE"),
        "habitual_mistakes_count": sum(1 for r in results if r["classification"] == "HABITUAL_MISTAKE"),
        "highest_friction_rule": results[0] if results else None,
        "telemetry_records": results
    }
    return summary

@router.post("/canon-refiner")
def run_canon_refiner_agent(payload: CanonRefineRequest, db=Depends(get_db)):
    """
    Triggers Canon Refiner Agent on an ambiguous rule (High GAS).
    Synthesizes human override feedback into an actionable guideline upgrade diff.
    """
    rule = db.query(GuidelineTelemetry).filter(GuidelineTelemetry.rule_id == payload.rule_id).first()
    rule_name = rule.rule_name if rule else "Bold Challenger Tone with Humble Understatement"

    sample_override_notes = [
        "Creator note: Guideline demands we be 'bold' but also 'humble'. We cannot tell if calling our sub-50ms engine 'industry-defining' is allowed.",
        "Reviewer note: Tone feels too aggressive for an enterprise pitch deck.",
        "Agency note: Brand guideline is contradictory; team spent 3 days debating humble vs bold."
    ]

    refiner_output = CanonRefinerAgent.generate_guideline_diff(
        rule_id=payload.rule_id,
        current_rule_text=rule_name,
        override_notes=sample_override_notes
    )
    return refiner_output

