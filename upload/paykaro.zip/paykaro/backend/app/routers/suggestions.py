import uuid
import datetime
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any

from backend.app.db.database import get_db
from backend.app.db.models import AuditFinding, SuggestionReview, GuidelineTelemetry, AuditLogEntry
from backend.app.services.ambiguity_service import calculate_guideline_ambiguity_score

router = APIRouter(prefix="/suggestions", tags=["Surgical Diffs & Collaborative Reviews"])

class AcceptDiffRequest(BaseModel):
    finding_id: str
    actor_role: str = "CREATOR"  # CREATOR, BRAND_MANAGER, LEGAL_COMPLIANCE, GOVERNANCE_ADMIN
    document_content: Optional[str] = None

class OverrideDiffRequest(BaseModel):
    finding_id: str
    actor_role: str = "CREATOR"
    override_reason: str = "INTENTIONAL_STYLE"  # INTENTIONAL_STYLE, UNCLEAR_GUIDELINE, APPROVED_EXCEPTION
    comment_text: str = "Author confirmed deliberate rhetorical emphasis."

class AddCommentRequest(BaseModel):
    finding_id: str
    actor_role: str
    comment_text: str

@router.post("/accept")
def accept_suggestion(payload: AcceptDiffRequest, db=Depends(get_db)):
    """
    Accepts suggested surgical diff:
    Applies change, records revision history, resolves linked comment thread.
    Atomic compare-and-swap (CAS) update guarantees that among concurrent reviewers,
    exactly ONE transaction succeeds and all others are safely rejected.
    """
    # 1. Atomic compare-and-swap update
    updated_rows = db.query(AuditFinding).filter(
        AuditFinding.finding_id == payload.finding_id,
        AuditFinding.status != "ACCEPTED"
    ).update({"status": "ACCEPTED"})
    db.commit()

    if updated_rows == 0:
        return {
            "status": "ALREADY_ACCEPTED",
            "finding_id": payload.finding_id,
            "message": "Suggestion was already accepted by a concurrent reviewer."
        }

    finding = db.query(AuditFinding).filter(AuditFinding.finding_id == payload.finding_id).first()

    # Create immutable review record
    review = SuggestionReview(
        review_id=f"rev-{uuid.uuid4().hex[:8]}",
        finding_id=payload.finding_id,
        action="ACCEPT",
        actor_role=payload.actor_role,
        resolved_at=datetime.datetime.utcnow()
    )
    db.add(review)

    # Append to Audit Log
    log = AuditLogEntry(
        log_id=f"log-{uuid.uuid4().hex[:8]}",
        action="DIFF_ACCEPTED",
        actor=payload.actor_role,
        details_json=f'{{"finding_id": "{payload.finding_id}", "rule_id": "{finding.rule_id if finding else "RULE-LIVE"}"}}'
    )
    db.add(log)

    db.commit()

    return {
        "status": "SUCCESS",
        "action": "ACCEPTED",
        "finding_id": payload.finding_id,
        "thread_status": "RESOLVED",
        "applied_diff": finding.suggested_diff if finding else None,
        "audit_log_id": log.log_id
    }

@router.post("/override")
def override_suggestion(payload: OverrideDiffRequest, db=Depends(get_db)):
    """
    Overrides / rejects AI suggestion:
    Preserves creator's original purpose, requires structured reason,
    feeds the Guideline Ambiguity Score (GAS) telemetry engine.
    """
    finding = db.query(AuditFinding).filter(AuditFinding.finding_id == payload.finding_id).first()
    if not finding:
        finding = AuditFinding(
            finding_id=payload.finding_id,
            audit_id="audit-live",
            pillar="VOICE",
            rule_id="RULE-VOICE-002",
            severity="MEDIUM",
            original_span="",
            status="PENDING",
            explanation="Overridden via Live UI"
        )
        db.add(finding)
        db.flush()

    finding.status = "OVERRIDDEN"

    review = SuggestionReview(
        review_id=f"rev-{uuid.uuid4().hex[:8]}",
        finding_id=finding.finding_id,
        action="OVERRIDE",
        actor_role=payload.actor_role,
        override_reason=payload.override_reason,
        comment_thread_json=f'[{{"author": "{payload.actor_role}", "comment": "{payload.comment_text}"}}]',
        comments_count=1,
        resolved_at=datetime.datetime.utcnow()
    )
    db.add(review)

    # Update Guideline Telemetry for GAS calculation
    telem = db.query(GuidelineTelemetry).filter(GuidelineTelemetry.rule_id == finding.rule_id).first()
    if telem:
        telem.overrides_count += 1
        telem.disputes_count += 1
        telem.mean_resolution_hours = min(48.0, telem.mean_resolution_hours + 1.2)
        
        gas_data = calculate_guideline_ambiguity_score(
            triggers=telem.triggers_count,
            overrides=telem.overrides_count,
            disputes=telem.disputes_count,
            mean_resolution_hours=telem.mean_resolution_hours
        )
        telem.gas_score = gas_data["gas_score"]
        telem.classification = gas_data["classification"]

    # Role-Based Access Control Routing check
    routed_queue = None
    if finding.pillar == "FACT_CLAIM" or "PROMO" in finding.rule_id:
        routed_queue = "LEGAL_AND_COMPLIANCE_REVIEW"
    elif finding.pillar == "VOICE" or finding.pillar == "VISUAL_GEOMETRY":
        routed_queue = "BRAND_MANAGER_APPROVAL"

    # Append to Audit Log
    log = AuditLogEntry(
        log_id=f"log-{uuid.uuid4().hex[:8]}",
        action="DIFF_OVERRIDDEN",
        actor=payload.actor_role,
        details_json=f'{{"finding_id": "{finding.finding_id}", "reason": "{payload.override_reason}", "routed_queue": "{routed_queue}"}}'
    )
    db.add(log)

    db.commit()

    return {
        "status": "SUCCESS",
        "action": "OVERRIDDEN",
        "finding_id": finding.finding_id,
        "override_reason": payload.override_reason,
        "routed_to": routed_queue,
        "updated_gas_score": telem.gas_score if telem else None,
        "classification": telem.classification if telem else "HABITUAL_MISTAKE"
    }
