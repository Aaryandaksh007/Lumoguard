from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any

from backend.app.db.database import get_db
from backend.app.db.models import CanonTerm, CanonVoice, CanonFact, CanonVisual, CanonLogo
from backend.app.engines.visual_geometry import hex_to_rgb, rgb_to_cielab
from backend.app.engines.accessibility_wcag import calculate_relative_luminance

router = APIRouter(prefix="/canon", tags=["Brand Canon Specification"])

class TermCreate(BaseModel):
    term_id: str
    surface_form: str
    rule_type: str = "DEPRECATED"
    replacement_token: Optional[str] = None
    allowed_context_regex: Optional[str] = None
    rationale_citation: str

class FactCreate(BaseModel):
    fact_id: str
    claim_assertion: str
    status: str = "CANONICAL"
    effective_date: Optional[str] = None
    expiration_date: Optional[str] = None
    evidence_doc_url: Optional[str] = None
    required_disclaimer_text: Optional[str] = None

class VisualCreate(BaseModel):
    token_name: str
    hex_value: str
    role: str = "PRIMARY"
    is_brand_core: bool = True

@router.get("/")
def get_brand_canon_overview(db=Depends(get_db)):
    terms = db.query(CanonTerm).all()
    voice = db.query(CanonVoice).first()
    facts = db.query(CanonFact).all()
    visuals = db.query(CanonVisual).all()
    logo = db.query(CanonLogo).first()

    return {
        "canon_version": "3.2.0-executable",
        "organization": "Inkloom AI",
        "last_updated": "2026-11-03",
        "terms_count": len(terms),
        "facts_count": len(facts),
        "visual_tokens_count": len(visuals),
        "terms": [
            {
                "term_id": t.term_id,
                "surface_form": t.surface_form,
                "rule_type": t.rule_type,
                "replacement_token": t.replacement_token,
                "allowed_context_regex": t.allowed_context_regex,
                "rationale_citation": t.rationale_citation
            }
            for t in terms
        ],
        "voice": {
            "voice_id": voice.voice_id if voice else "VOICE-001",
            "persona_name": voice.persona_name if voice else "Grounded Technical",
            "flesch_kincaid_range": [voice.flesch_kincaid_min if voice else 8.0, voice.flesch_kincaid_max if voice else 12.0],
            "passive_voice_ceiling": f"{voice.passive_voice_max_pct if voice else 15.0}%"
        },
        "facts": [
            {
                "fact_id": f.fact_id,
                "claim_assertion": f.claim_assertion,
                "status": f.status,
                "evidence_doc_url": f.evidence_doc_url,
                "required_disclaimer_text": f.required_disclaimer_text
            }
            for f in facts
        ],
        "visuals": [
            {
                "token_name": v.token_name,
                "hex": v.hex_value,
                "role": v.role,
                "wcag_luminance": v.wcag_luminance,
                "cie_lab": [v.cie_l, v.cie_a, v.cie_b]
            }
            for v in visuals
        ],
        "logo_rules": {
            "canonical_aspect_ratio": logo.aspect_ratio if logo else 4.0,
            "min_clear_space_margin": f"{int((logo.clear_space_ratio if logo else 0.25) * 100)}% of height"
        }
    }

@router.post("/term")
def create_or_update_term(payload: TermCreate, db=Depends(get_db)):
    term = db.query(CanonTerm).filter(CanonTerm.term_id == payload.term_id).first()
    if not term:
        term = CanonTerm(term_id=payload.term_id)
        db.add(term)
    term.surface_form = payload.surface_form
    term.rule_type = payload.rule_type
    term.replacement_token = payload.replacement_token
    term.allowed_context_regex = payload.allowed_context_regex
    term.rationale_citation = payload.rationale_citation
    db.commit()
    return {"status": "SUCCESS", "term_id": term.term_id}

@router.post("/fact")
def create_or_update_fact(payload: FactCreate, db=Depends(get_db)):
    fact = db.query(CanonFact).filter(CanonFact.fact_id == payload.fact_id).first()
    if not fact:
        fact = CanonFact(fact_id=payload.fact_id)
        db.add(fact)
    fact.claim_assertion = payload.claim_assertion
    fact.status = payload.status
    fact.effective_date = payload.effective_date
    fact.expiration_date = payload.expiration_date
    fact.evidence_doc_url = payload.evidence_doc_url
    fact.required_disclaimer_text = payload.required_disclaimer_text
    db.commit()
    return {"status": "SUCCESS", "fact_id": fact.fact_id}

@router.post("/visual")
def create_visual_token(payload: VisualCreate, db=Depends(get_db)):
    r, g, b = hex_to_rgb(payload.hex_value)
    cie_l, cie_a, cie_b = rgb_to_cielab(r, g, b)
    wcag_lum = calculate_relative_luminance(r, g, b)

    token = db.query(CanonVisual).filter(CanonVisual.token_name == payload.token_name).first()
    if not token:
        token = CanonVisual(token_name=payload.token_name)
        db.add(token)

    token.hex_value = payload.hex_value
    token.r, token.g, token.b = r, g, b
    token.cie_l, token.cie_a, token.cie_b = cie_l, cie_a, cie_b
    token.wcag_luminance = wcag_lum
    token.role = payload.role
    token.is_brand_core = payload.is_brand_core

    db.commit()
    return {"status": "SUCCESS", "token_name": token.token_name}

