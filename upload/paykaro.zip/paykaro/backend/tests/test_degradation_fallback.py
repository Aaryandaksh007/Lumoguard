import pytest
import time
from backend.app.services.orchestrator import VerificationOrchestrator

def test_deterministic_graceful_degradation_under_llm_timeout():
    """
    Blueprint Section 7.2:
    Deterministic Graceful Degradation Test simulating an external LLM timeout/failure.
    Verifies that all Stage 1 deterministic checks (Terminology, WCAG 2.2 contrast,
    CIEDE2000 color palette, logo clear space, Presidio confidentiality) return in < 150ms.
    """
    terms = [{
        "term_id": "TERM-001",
        "surface_form": "InkLoom",
        "rule_type": "DEPRECATED",
        "replacement_token": "Inkloom AI",
        "rationale_citation": "Brand Canon §1.2"
    }]

    visuals = [
        {"token_name": "Brand-Blue-700", "hex": "#1D4ED8", "role": "PRIMARY", "wcag_luminance": 0.088},
        {"token_name": "Brand-Slate-50", "hex": "#F8FAFC", "role": "SURFACE", "wcag_luminance": 0.957}
    ]

    orchestrator = VerificationOrchestrator(
        terms_data=terms,
        visual_tokens=visuals,
        confidential_codenames=["Project Chronos"]
    )

    test_content = (
        "Internal Draft: Project Chronos launch built with InkLoom. "
        "Delve into our platform to harness the power of AI."
    )

    visual_meta = {
        "extracted_colors": [{"name": "Accent", "hex": "#2563EB"}],
        "color_pairs": [{"fg": "#60A5FA", "bg": "#F8FAFC", "is_large": False}],
        "logo_box": {"width": 120.0, "height": 50.0, "adjacent_text_dist": 4.0}
    }

    t0 = time.perf_counter()
    # Force air-gapped / degraded mode
    result = orchestrator.run_preflight_audit(
        title="Degradation Test Asset",
        content=test_content,
        asset_type="MARKDOWN",
        visual_meta=visual_meta,
        is_air_gapped=True
    )
    total_ms = (time.perf_counter() - t0) * 1000.0

    # Total latency must be well under 150ms
    assert total_ms < 150.0, f"Expected < 150ms, got {total_ms}ms"

    # Stage 1 deterministic latency must be sub-50ms
    assert result["stage1_latency_ms"] < 50.0, f"Stage 1 took {result['stage1_latency_ms']}ms"

    # All deterministic pillars must be successfully audited
    pillars = set(f["pillar"] for f in result["findings"])
    assert "CONFIDENTIALITY" in pillars
    assert "TERMINOLOGY" in pillars
    assert "VOICE" in pillars
    assert "VISUAL_GEOMETRY" in pillars
    assert "ACCESSIBILITY_WCAG" in pillars

