import pytest
from backend.app.services.ambiguity_service import (
    calculate_guideline_ambiguity_score, CanonRefinerAgent
)

def test_guideline_ambiguity_score_formula_and_quadrant():
    """
    Secret Weapon #1 Test:
    Validates exact GAS mathematical scores from Blueprint Section 5.2.
    """
    # Rule A: Clear Rule / Habitual Creator Mistake
    # Triggers = 40, Overrides = 3, Disputes = 2, Latency = 1.5h
    # GAS_A = ln(41) * [ 0.5 * (3/40) + 0.3 * (2/40) + 0.2 * (1.5/48) ] = 3.7136 * [ 0.0375 + 0.015 + 0.00625 ] = 0.218
    res_a = calculate_guideline_ambiguity_score(
        triggers=40,
        overrides=3,
        disputes=2,
        mean_resolution_hours=1.5,
        max_sla_hours=48.0
    )
    assert 0.20 <= res_a["gas_score"] <= 0.23, f"Expected ~0.218, got {res_a['gas_score']}"
    assert res_a["classification"] == "HABITUAL_MISTAKE"

    # Rule B: Unclear Brand Guideline / High Friction
    # Triggers = 35, Overrides = 22, Disputes = 18, Latency = 36.0h
    # GAS_B = ln(36) * [ 0.5 * (22/35) + 0.3 * (18/35) + 0.2 * (36/48) ] = 3.5835 * [ 0.3143 + 0.1543 + 0.1500 ] = 2.217
    res_b = calculate_guideline_ambiguity_score(
        triggers=35,
        overrides=22,
        disputes=18,
        mean_resolution_hours=36.0,
        max_sla_hours=48.0
    )
    assert 2.15 <= res_b["gas_score"] <= 2.25, f"Expected ~2.217, got {res_b['gas_score']}"
    assert res_b["classification"] == "UNCLEAR_GUIDELINE"

    # Contrast ratio between ambiguous vs clear rule
    ratio = res_b["gas_score"] / res_a["gas_score"]
    assert ratio >= 9.5, f"GAS_B should be ~10x higher than GAS_A, got ratio {ratio}"

def test_canon_refiner_agent():
    """
    Improvement #2 Test: Canon Refiner Agent generates structured Do/Don't diff.
    """
    rule_id = "RULE-VOICE-002"
    rule_name = "Bold Challenger Tone with Humble Understatement"
    notes = [
        "Creator note: Guideline demands we be bold but also humble.",
        "Reviewer note: Tone is contradictory."
    ]

    diff_spec = CanonRefinerAgent.generate_guideline_diff(rule_id, rule_name, notes)

    assert diff_spec["rule_id"] == rule_id
    assert len(diff_spec["do_examples"]) >= 2
    assert len(diff_spec["dont_examples"]) >= 2
    assert "DO:" in diff_spec["do_examples"][0]
    assert "DON'T:" in diff_spec["dont_examples"][0]

