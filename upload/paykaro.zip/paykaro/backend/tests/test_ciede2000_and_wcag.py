import pytest
from backend.app.engines.visual_geometry import (
    hex_to_rgb, rgb_to_cielab, ciede2000, VisualGeometryEngine
)
from backend.app.engines.accessibility_wcag import (
    calculate_contrast_ratio, calculate_relative_luminance, AccessibilityWCAGEngine
)

def test_hex_to_rgb_and_cielab():
    # Test Brand-Blue-700 (#1D4ED8)
    r, g, b = hex_to_rgb("#1D4ED8")
    assert (r, g, b) == (29, 78, 216)

    lab = rgb_to_cielab(r, g, b)
    assert len(lab) == 3
    # L* should be around 37.5
    assert 35.0 <= lab[0] <= 40.0

def test_ciede2000_color_drift_values():
    # Identity test: distance between identical swatches is exactly 0.0
    lab1 = rgb_to_cielab(*hex_to_rgb("#1D4ED8"))
    assert ciede2000(lab1, lab1) == 0.0

    # Near-miss Tailwind Blue-600 (#2563EB) vs Approved (#1D4ED8)
    # Expected ΔE00 is approx 7.13
    lab_near_miss = rgb_to_cielab(*hex_to_rgb("#2563EB"))
    delta_e_near_miss = ciede2000(lab1, lab_near_miss)
    assert 6.5 <= delta_e_near_miss <= 7.8, f"Got {delta_e_near_miss}"

    # Rogue swatch Violet (#7C3AED) vs Approved (#1D4ED8)
    # Expected ΔE00 is approx 12.39
    lab_rogue = rgb_to_cielab(*hex_to_rgb("#7C3AED"))
    delta_e_rogue = ciede2000(lab1, lab_rogue)
    assert 11.5 <= delta_e_rogue <= 13.5, f"Got {delta_e_rogue}"

def test_wcag_22_relative_luminance_and_contrast_ratios():
    # White (#FFFFFF) luminance is 1.0
    white_lum = calculate_relative_luminance(*hex_to_rgb("#FFFFFF"))
    assert abs(white_lum - 1.0) < 0.001

    # Black (#000000) luminance is 0.0
    black_lum = calculate_relative_luminance(*hex_to_rgb("#000000"))
    assert abs(black_lum - 0.0) < 0.001

    # 1. Creator Draft: #60A5FA on Slate #F8FAFC -> CR ~ 2.43:1 (FAILS WCAG AA < 4.5:1)
    cr_failing = calculate_contrast_ratio("#60A5FA", "#F8FAFC")
    assert 2.35 <= cr_failing <= 2.50, f"Got {cr_failing}"
    assert cr_failing < 4.5, "Expected failure of WCAG 2.2 AA normal text threshold"

    # 2. Approved Canon Baseline: #1D4ED8 on Slate #F8FAFC -> CR ~ 6.41:1 (PASSES WCAG AA)
    cr_slate = calculate_contrast_ratio("#1D4ED8", "#F8FAFC")
    assert 6.20 <= cr_slate <= 6.60, f"Got {cr_slate}"
    assert cr_slate >= 4.5, "Expected pass of WCAG 2.2 AA"

    # 3. Approved Canon Baseline: #1D4ED8 on White #FFFFFF -> CR ~ 6.70:1 (PASSES WCAG AA)
    cr_white = calculate_contrast_ratio("#1D4ED8", "#FFFFFF")
    assert 6.50 <= cr_white <= 6.90, f"Got {cr_white}"
    assert cr_white >= 4.5

def test_auto_contrast_on_brand_token_resolver():
    """
    Improvement #1 Test: Auto-Contrast Token Resolver selects closest on-brand swatch.
    """
    engine = AccessibilityWCAGEngine()
    result = engine.resolve_auto_contrast_on_brand_token(
        failing_fg_hex="#60A5FA",
        bg_hex="#F8FAFC",
        required_cr=4.5
    )
    assert result is not None
    # Must pick Brand-Blue-700 (#1D4ED8)
    assert result["hex"] == "#1D4ED8"
    assert result["contrast_ratio"] >= 4.5
    assert result["token_name"] == "Brand-Blue-700"

def test_logo_geometry_and_clear_space():
    engine = VisualGeometryEngine()

    # Distorted aspect ratio: 120x50 = 2.40 (Canonical is 4.00, diff = 1.60 > 0.02)
    # Clear space violated: 4.5px < (50 * 0.25 = 12.5px)
    logo_box = {
        "width": 120.0,
        "height": 50.0,
        "adjacent_text_dist": 4.5
    }

    findings = engine.check_logo_geometry(logo_box)
    assert len(findings) == 2

    rule_ids = [f["rule_id"] for f in findings]
    assert "RULE-LOGO-ASPECT-RATIO" in rule_ids
    assert "RULE-LOGO-CLEAR-SPACE" in rule_ids

