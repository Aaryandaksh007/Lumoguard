import pytest
import time
from backend.app.engines.terminology import TerminologyEngine

def test_sub_5ms_aho_corasick_and_grammar_adjustment():
    terms = [
        {
            "term_id": "TERM-001",
            "surface_form": "InkLoom",
            "rule_type": "DEPRECATED",
            "replacement_token": "Inkloom AI",
            "allowed_context_regex": r"(?i)formerly known as InkLoom",
            "rationale_citation": "Brand Canon §1.2"
        },
        {
            "term_id": "TERM-002",
            "surface_form": "AI magic",
            "rule_type": "FORBIDDEN",
            "replacement_token": "intelligent verification",
            "allowed_context_regex": None,
            "rationale_citation": "Brand Canon §3.1"
        }
    ]

    engine = TerminologyEngine(terms)

    # Test 1: Flagged violation with article adjustment ('an InkLoom' -> 'an Inkloom AI')
    t0 = time.perf_counter()
    text = "We built an InkLoom platform with AI magic."
    findings = engine.audit_text(text)
    latency_ms = (time.perf_counter() - t0) * 1000.0

    assert latency_ms < 5.0, f"Execution took {latency_ms}ms, expected < 5ms"
    assert len(findings) == 2

    # Verify findings contain citations and suggested diffs
    f_term = next(f for f in findings if f["rule_id"] == "TERM-001")
    assert "Inkloom AI" in f_term["suggested_diff"]
    assert f_term["provenance"]["engine"] == "DETERMINISTIC_ENGINE_LOCAL"

    # Test 2: Allowed Context Exception (e.g. 'formerly known as InkLoom')
    exception_text = "Inkloom AI was formerly known as InkLoom in our early alpha."
    exception_findings = engine.audit_text(exception_text)
    # The term 'InkLoom' inside the allowed regex should NOT be flagged
    assert len(exception_findings) == 0

