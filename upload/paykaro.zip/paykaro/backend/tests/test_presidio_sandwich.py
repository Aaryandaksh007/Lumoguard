import pytest
from backend.app.engines.confidentiality_shield import ConfidentialityShieldEngine

def test_presidio_sandwich_pattern_reversible_tokenization():
    """
    Improvement #3 Test:
    Confidential codename masking, scrubbed payload verification,
    and longest-first de-anonymization.
    """
    shield = ConfidentialityShieldEngine(confidential_codenames=["Project Chronos", "Project Titan"])

    raw_text = (
        "Internal roadmap: Project Chronos and Project Titan are led by "
        "Alice Smith (alice@inkloom.ai, 555-0199)."
    )

    # 1. Redact and tokenize
    scrubbed, token_map, entities = shield.redact_and_tokenize(raw_text)

    # Secrets and PII must not appear in scrubbed output
    assert "Project Chronos" not in scrubbed
    assert "Project Titan" not in scrubbed
    assert "alice@inkloom.ai" not in scrubbed

    # Tokens must be present
    assert "{{SECRET_CODENAME_" in scrubbed

    # 2. Simulate external LLM processing
    llm_critique = f"Reviewing: '{scrubbed}'. The tone is appropriate."

    # 3. Longest-first de-anonymization
    restored = shield.de_anonymize(llm_critique, token_map)

    # Verify original entities are cleanly restored
    assert "Project Chronos" in restored
    assert "Project Titan" in restored
    assert "alice@inkloom.ai" in restored

def test_longest_placeholder_first_no_prefix_corruption():
    """
    Ensures that placeholder tokens with common prefixes (e.g. {{PERSON_1}} vs {{PERSON_10}})
    are never corrupted by naive substitution.
    """
    shield = ConfidentialityShieldEngine()

    dummy_map = {
        "{{PERSON_1}}": "Bob",
        "{{PERSON_10}}": "Alexander Hamilton"
    }

    test_input = "Attendees: {{PERSON_1}} and {{PERSON_10}}."
    restored = shield.de_anonymize(test_input, dummy_map)

    # If sorted longest-first, {{PERSON_10}} is substituted before {{PERSON_1}}
    assert restored == "Attendees: Bob and Alexander Hamilton."

