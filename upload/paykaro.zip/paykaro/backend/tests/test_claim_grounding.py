import pytest
from backend.app.engines.claim_grounding import ClaimGroundingEngine

def test_atomic_claim_grounding_and_verdicts():
    facts = [
        {
            "fact_id": "FACT-001",
            "claim_assertion": "Inkloom AI delivers sub-50ms deterministic passes.",
            "status": "CANONICAL",
            "evidence_doc_url": "https://inkloom.ai/benchmarks"
        },
        {
            "fact_id": "FACT-002",
            "claim_assertion": "Enterprise plan is $79 per user monthly billed annually.",
            "status": "CANONICAL",
            "evidence_doc_url": "https://inkloom.ai/pricing"
        },
        {
            "fact_id": "FACT-004",
            "claim_assertion": "LoomGuard provides real-time print dieline checking.",
            "status": "ROADMAP_ASPIRATIONAL",
            "evidence_doc_url": "https://inkloom.ai/roadmap"
        },
        {
            "fact_id": "FACT-005",
            "claim_assertion": "Assistive brand governance without legal substitution.",
            "status": "CANONICAL",
            "evidence_doc_url": "https://inkloom.ai/legal",
            "required_disclaimer_text": "Disclaimer: LoomGuard does not constitute formal legal counsel."
        }
    ]

    engine = ClaimGroundingEngine(facts)

    test_doc = (
        "Our engine delivers sub-50ms deterministic verification passes. "
        "The Enterprise plan is available at $49 per user monthly. "
        "Inkloom AI provides real-time print dieline checking and replaces your entire legal team with 100% accuracy."
    )

    findings = engine.audit_text(test_doc)
    verdicts = [f.get("verdict") for f in findings]

    # Verify each expected verdict is present
    assert "VERIFIED_CANONICAL" in verdicts
    assert "OUTDATED_FACT" in verdicts
    assert "ASPIRATIONAL_STATED_AS_PRESENT" in verdicts
    assert "UNSUBSTANTIATED_PROMOTIONAL_CLAIM" in verdicts
    assert "MISSING_MANDATORY_DISCLAIMER" in verdicts

    # Outdated pricing diff check ($49 -> $79)
    outdated_f = next(f for f in findings if f["verdict"] == "OUTDATED_FACT")
    assert "$79" in outdated_f["suggested_diff"]

    # Superlative claim diff check (softens claim, avoids strict liability)
    promo_f = next(f for f in findings if f["verdict"] == "UNSUBSTANTIATED_PROMOTIONAL_CLAIM")
    assert "accelerates" in promo_f["suggested_diff"]

