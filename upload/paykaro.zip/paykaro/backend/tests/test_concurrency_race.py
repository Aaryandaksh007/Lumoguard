import concurrent.futures
import pytest
from backend.app.db.database import SessionLocal, engine, Base
from backend.app.db.models import AuditFinding, SuggestionReview
from backend.app.routers.suggestions import accept_suggestion, AcceptDiffRequest

def test_25_way_concurrent_race_condition():
    """
    Inkloom Engineering Standard Reliability Test (Blueprint Section 7.2):
    Fires 25 simultaneous transactions against the database attempting
    to accept the same finding concurrently. Asserts that exactly ONE
    transition commits without deadlock or state corruption.
    """
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    # Create a unique test finding
    test_finding_id = "find-race-test-001"
    existing = db.query(AuditFinding).filter(AuditFinding.finding_id == test_finding_id).first()
    if existing:
        db.delete(existing)
        db.commit()

    finding = AuditFinding(
        finding_id=test_finding_id,
        audit_id="audit-race",
        pillar="TERMINOLOGY",
        rule_id="RULE-TERM-001",
        severity="MEDIUM",
        original_span="InkLoom",
        suggested_diff="Inkloom AI",
        provenance_json="{}",
        status="PENDING",
        explanation="Race condition benchmark finding"
    )
    db.add(finding)
    db.commit()
    db.close()

    def attempt_accept(worker_id: int):
        worker_db = SessionLocal()
        try:
            req = AcceptDiffRequest(
                finding_id=test_finding_id,
                actor_role=f"CREATOR_{worker_id}"
            )
            res = accept_suggestion(req, db=worker_db)
            return res
        finally:
            worker_db.close()

    # Launch 25 simultaneous concurrent threads
    with concurrent.futures.ThreadPoolExecutor(max_workers=25) as executor:
        futures = [executor.submit(attempt_accept, i) for i in range(25)]
        results = [f.result() for f in concurrent.futures.as_completed(futures)]

    # Exactly one request should succeed with action "ACCEPTED"
    accepted_count = sum(1 for r in results if r.get("action") == "ACCEPTED")
    already_accepted_count = sum(1 for r in results if r.get("status") == "ALREADY_ACCEPTED")

    assert accepted_count == 1, f"Expected exactly 1 accepted transaction, got {accepted_count}"
    assert already_accepted_count == 24, f"Expected 24 already-accepted rejects, got {already_accepted_count}"

    # Verify database state
    verify_db = SessionLocal()
    f_final = verify_db.query(AuditFinding).filter(AuditFinding.finding_id == test_finding_id).first()
    reviews = verify_db.query(SuggestionReview).filter(SuggestionReview.finding_id == test_finding_id).all()

    assert f_final.status == "ACCEPTED"
    assert len(reviews) == 1
    verify_db.close()
