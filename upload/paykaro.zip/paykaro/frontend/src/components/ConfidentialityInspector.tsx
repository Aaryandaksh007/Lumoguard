import React, { useState } from 'react';
import { Shield, Sparkles, Lock, ArrowRight, CheckCircle2, Cpu, Key, User, Mail, ShieldAlert } from 'lucide-react';

export const ConfidentialityInspector: React.FC = () => {
  const [inputText, setInputText] = useState<string>(
    'Confidential Pre-Launch Brief: Project Chronos is scheduled for Q3 announcement by Sarah Connor (sarah@inkloom.ai). Project Chronos will deliver 10x faster verification.'
  );

  const [inspectionResult, setInspectionResult] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleInspect = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/v1/confidentiality/inspect-sandwich', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ raw_text: inputText }),
      });
      if (res.ok) {
        const data = await res.json();
        setInspectionResult(data);
      }
    } catch (e) {
      console.error('Inspection failed', e);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="glass-card rounded-2xl p-6 space-y-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-700 text-white shadow-lg shadow-purple-500/20">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-white">Privacy Shield: The Sandwich Pattern</h2>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-500/15 text-purple-300 border border-purple-500/20">
                Presidio Airlock
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Zero sensitive project codenames or customer PII leave the local perimeter. Test reversible redaction in real time.
            </p>
          </div>
        </div>
      </div>

      {/* Input Sandbox */}
      <div className="glass-card rounded-2xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
            Draft with Brand Codenames & PII
          </label>
          <span className="text-[11px] text-purple-400 font-mono flex items-center gap-1">
            <Lock className="w-3 h-3" /> Pre-Flight Scrub Active
          </span>
        </div>

        <textarea
          rows={3}
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          className="w-full bg-slate-950/80 border border-slate-800/80 rounded-xl p-3.5 font-mono text-xs text-slate-200 focus:outline-none focus:border-purple-500/60 resize-none leading-relaxed transition-colors"
        />

        <div className="flex items-center justify-between pt-1">
          <div className="flex items-center gap-3 text-xs text-slate-400">
            <span className="flex items-center gap-1">
              <Key className="w-3.5 h-3.5 text-purple-400" /> Codenames
            </span>
            <span className="flex items-center gap-1">
              <User className="w-3.5 h-3.5 text-blue-400" /> Person PII
            </span>
            <span className="flex items-center gap-1">
              <Mail className="w-3.5 h-3.5 text-emerald-400" /> Email PII
            </span>
          </div>

          <button
            onClick={handleInspect}
            disabled={isLoading}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-xs font-bold text-white flex items-center gap-2 shadow-lg shadow-purple-600/20 transition-all hover:scale-[1.02] disabled:opacity-50"
          >
            {isLoading ? (
              <span className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Scrubbing with Presidio...
              </span>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                Execute Reversible Sandwich Check
              </>
            )}
          </button>
        </div>
      </div>

      {/* Live 3-Stage Pipeline Results */}
      {inspectionResult && (
        <div className="glass-card rounded-2xl p-6 space-y-6 glow-purple animate-scale-in">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/60">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <h3 className="text-base font-bold text-white">Reversible Sandwich Execution Proof</h3>
            </div>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-950/40 px-2.5 py-1 rounded-lg border border-emerald-500/20">
              {inspectionResult.privacy_guarantee}
            </span>
          </div>

          <div className="space-y-4 text-xs">
            {/* Step 1: Pre-Flight Local Entity Recognition */}
            <div className="bg-slate-950/60 rounded-xl p-4 border border-slate-800/60 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 font-semibold uppercase text-[11px] block">
                  Step 1: Local Entity Detection (Microsoft Presidio)
                </span>
                <span className="text-[10px] text-purple-300 font-mono">
                  {inspectionResult.step_2_detected_entities?.length || 0} entities quarantined
                </span>
              </div>
              <div className="flex flex-wrap gap-2 pt-1">
                {inspectionResult.step_2_detected_entities.map((ent: any, idx: number) => (
                  <span
                    key={idx}
                    className="px-2.5 py-1 rounded-lg bg-purple-950/40 text-purple-200 border border-purple-500/30 font-mono text-[11px] flex items-center gap-1.5"
                  >
                    <Key className="w-3 h-3 text-purple-400" />
                    <span>{ent.entity_type}:</span> <strong>"{ent.text}"</strong> (Confidence: {ent.score})
                  </span>
                ))}
              </div>
            </div>

            {/* Step 2: Scrubbed Payload Sent to External LLM */}
            <div className="bg-slate-950/60 rounded-xl p-4 border border-slate-800/60 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 font-semibold uppercase text-[11px]">
                  Step 2: Scrubbed Payload Sent to External Cloud LLM
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-300 font-mono border border-emerald-500/20">
                  100% Codenames Scrubbed
                </span>
              </div>
              <p className="font-mono text-purple-300 bg-slate-900/90 p-3 rounded-lg border border-purple-500/20 leading-relaxed text-xs">
                {inspectionResult.step_3_scrubbed_payload_sent_to_llm}
              </p>
            </div>

            {/* Step 3: Longest-First Restored Output */}
            <div className="bg-slate-950/60 rounded-xl p-4 border border-slate-800/60 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 font-semibold uppercase text-[11px]">
                  Step 3: Longest-First De-Anonymization Output
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-blue-500/15 text-blue-300 font-mono border border-blue-500/20">
                  Zero Token Prefix Collision
                </span>
              </div>
              <p className="font-mono text-emerald-300 bg-slate-900/90 p-3 rounded-lg border border-emerald-500/20 leading-relaxed text-xs">
                {inspectionResult.step_5_restored_clean_output}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
