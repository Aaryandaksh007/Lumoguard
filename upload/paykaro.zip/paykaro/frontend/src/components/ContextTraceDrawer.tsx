import React from 'react';
import { X, Shield, Cpu, Clock, Link as LinkIcon, ArrowDown, Zap, BookOpen, Eye } from 'lucide-react';
import { Finding } from '../types';

interface ContextTraceDrawerProps {
  finding: Finding | null;
  onClose: () => void;
}

export const ContextTraceDrawer: React.FC<ContextTraceDrawerProps> = ({ finding, onClose }) => {
  if (!finding) return null;

  const prov = finding.provenance;
  const isDeterministic = prov.engine.includes('DETERMINISTIC');

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 animate-overlay-in"
        onClick={onClose}
      />

      {/* Drawer */}
      <div className="fixed inset-y-0 right-0 w-full max-w-md bg-slate-900 border-l border-slate-800/60 shadow-2xl z-50 flex flex-col animate-drawer-in">
        {/* Gradient accent */}
        <div className="h-1 bg-gradient-to-r from-indigo-500 via-blue-500 to-cyan-500 flex-shrink-0" />

        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800/60 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white">Why was this flagged?</h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Full audit trail and provenance</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Timeline Body */}
        <div className="p-6 space-y-0 overflow-y-auto flex-1">
          {/* Step 1: Engine */}
          <div className="flex gap-4">
            <div className="flex flex-col items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                isDeterministic ? 'bg-emerald-500/15 border border-emerald-500/30' : 'bg-purple-500/15 border border-purple-500/30'
              }`}>
                <Zap className={`w-4 h-4 ${isDeterministic ? 'text-emerald-400' : 'text-purple-400'}`} />
              </div>
              <div className="w-0.5 h-full bg-gradient-to-b from-slate-700 to-slate-800 mt-2" />
            </div>
            <div className="pb-6 flex-1">
              <div className="text-xs font-semibold text-white mb-1">Verification Engine</div>
              <div className="glass-card rounded-lg p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    isDeterministic ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/20' : 'bg-purple-500/15 text-purple-300 border border-purple-500/20'
                  }`}>
                    {isDeterministic ? '⚡ Deterministic' : '🧠 Semantic AI'}
                  </span>
                  <span className="text-xs font-mono text-emerald-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {prov.latency_ms}ms
                  </span>
                </div>
                <div className="text-[11px] text-slate-400">
                  <span className="text-slate-500">Algorithm:</span>{' '}
                  <span className="text-slate-300">{prov.algorithm || 'Rule Evaluator'}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Step 2: Rule */}
          <div className="flex gap-4">
            <div className="flex flex-col items-center">
              <div className="w-8 h-8 rounded-full bg-blue-500/15 border border-blue-500/30 flex items-center justify-center flex-shrink-0">
                <BookOpen className="w-4 h-4 text-blue-400" />
              </div>
              <div className="w-0.5 h-full bg-gradient-to-b from-slate-700 to-slate-800 mt-2" />
            </div>
            <div className="pb-6 flex-1">
              <div className="text-xs font-semibold text-white mb-1">Brand Rule Matched</div>
              <div className="glass-card rounded-lg p-3 space-y-2">
                <div className="text-xs text-slate-300 font-medium leading-relaxed border-l-2 border-blue-500/40 pl-3 bg-blue-950/10 py-1.5 rounded-r">
                  {prov.citation || 'Inkloom Brand Canon Specification v3.2'}
                </div>

                {prov.matched_fact_id && (
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-400">Grounding Fact:</span>
                    <span className="text-blue-400 font-mono font-medium">{prov.matched_fact_id}</span>
                  </div>
                )}

                {prov.evidence_url && (
                  <a
                    href={prov.evidence_url}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 text-[11px] text-blue-400 hover:text-blue-300 underline"
                  >
                    <LinkIcon className="w-3 h-3" />
                    View evidence document
                  </a>
                )}

                <div className="text-[11px] text-slate-500">
                  Context mode: <span className="text-slate-400 font-mono">{prov.context_mode || 'LOCKED_CANON_RULE'}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Step 3: Privacy */}
          <div className="flex gap-4">
            <div className="flex flex-col items-center">
              <div className="w-8 h-8 rounded-full bg-purple-500/15 border border-purple-500/30 flex items-center justify-center flex-shrink-0">
                <Shield className="w-4 h-4 text-purple-400" />
              </div>
            </div>
            <div className="pb-6 flex-1">
              <div className="text-xs font-semibold text-white mb-1">Privacy Check</div>
              <div className="glass-card rounded-lg p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">Confidentiality verified</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-purple-500/15 text-purple-300 border border-purple-500/20">
                    Presidio ✓
                  </span>
                </div>
                <div className="text-[11px] font-mono text-purple-300/80 bg-slate-950/60 p-2.5 rounded border border-purple-500/10 leading-relaxed">
                  {prov.sanitized_payload_preview ||
                    'Scrubbed: "Initiative {{SECRET_CODENAME_1}} reviewed by {{PERSON_1}} under {{EMAIL_ADDRESS_1}}."'}
                </div>
              </div>
            </div>
          </div>

          {/* Audited element */}
          <div className="pt-4 border-t border-slate-800/60 space-y-3">
            <div>
              <span className="text-[11px] text-slate-400 font-medium block mb-1">Flagged content</span>
              <div className="p-2.5 rounded-lg bg-red-950/15 font-mono text-xs text-red-300 border border-red-500/15">
                {finding.original_span}
              </div>
            </div>
            {finding.suggested_diff && (
              <div>
                <span className="text-[11px] text-slate-400 font-medium block mb-1">
                  Suggested fix ({Math.round((finding.intent_preservation_score || 1.0) * 100)}% meaning preserved)
                </span>
                <div className="p-2.5 rounded-lg bg-emerald-950/15 font-mono text-xs text-emerald-300 border border-emerald-500/15">
                  {finding.suggested_diff}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-sm font-medium text-slate-200 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </>
  );
};
