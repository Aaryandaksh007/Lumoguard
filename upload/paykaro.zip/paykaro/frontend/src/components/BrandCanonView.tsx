import React, { useState, useEffect } from 'react';
import { BookOpen, Palette, Check, FileCheck, Layers, ShieldCheck, ExternalLink, Type, Scale, MessageSquare } from 'lucide-react';
import { CanonOverview } from '../types';

export const BrandCanonView: React.FC = () => {
  const [canon, setCanon] = useState<CanonOverview | null>(null);
  const [activeTab, setActiveTab] = useState<'terms' | 'facts' | 'visuals' | 'voice'>('terms');

  useEffect(() => {
    fetch('/api/v1/canon')
      .then((res) => res.json())
      .then((data) => setCanon(data))
      .catch((err) => console.error('Failed to load canon', err));
  }, []);

  if (!canon) {
    return (
      <div className="glass-card rounded-2xl p-12 text-center text-slate-400 space-y-3">
        <div className="w-8 h-8 border-2 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin mx-auto" />
        <p className="text-xs">Loading Executable Brand Canon Specification...</p>
      </div>
    );
  }

  const subtabs = [
    { id: 'terms', label: 'Word Rules', icon: Type },
    { id: 'facts', label: 'Approved Claims', icon: Scale },
    { id: 'visuals', label: 'Color & Logo', icon: Palette },
    { id: 'voice', label: 'Tone Profile', icon: MessageSquare },
  ];

  return (
    <div className="space-y-6">
      {/* Canon Header */}
      <div className="glass-card rounded-2xl p-6 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-br from-indigo-500 to-blue-600 text-white shadow-lg shadow-indigo-500/20">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-white">Brand Canon Specification</h2>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 font-mono border border-emerald-500/20">
                v{canon.canon_version}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Source of truth and constraint ledger for {canon.organization}. Compiled for sub-50ms deterministic lookup.
            </p>
          </div>
        </div>

        {/* Sub-nav */}
        <div className="flex items-center gap-1 bg-slate-950/60 p-1 rounded-xl border border-slate-800/60">
          {subtabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-slate-850'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab 1: Terms */}
      {activeTab === 'terms' && (
        <div className="glass-card rounded-2xl overflow-hidden">
          <div className="p-4 border-b border-slate-800/60 flex items-center justify-between bg-slate-950/40">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Lexicon & Terminology Rules (Aho-Corasick Automaton Compiled)
            </span>
            <span className="text-xs font-mono text-slate-400">{canon.terms.length} active patterns</span>
          </div>

          <div className="divide-y divide-slate-800/60">
            {canon.terms.map((t) => (
              <div key={t.term_id} className="p-4 hover:bg-slate-800/30 transition-colors flex flex-wrap items-center justify-between text-xs gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-white bg-slate-950/80 px-2 py-0.5 rounded border border-slate-800">
                      {t.surface_form}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      t.rule_type === 'FORBIDDEN' ? 'bg-red-500/15 text-red-300 border border-red-500/20' : 'bg-amber-500/15 text-amber-300 border border-amber-500/20'
                    }`}>
                      {t.rule_type}
                    </span>
                    <span className="font-mono text-[10px] text-slate-500">ID: {t.term_id}</span>
                  </div>
                  <p className="text-slate-400 leading-relaxed text-[11px]">{t.rationale_citation}</p>
                </div>

                {t.replacement_token && (
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block mb-1">Approved Replacement:</span>
                    <span className="font-mono font-bold text-emerald-400 bg-emerald-950/40 px-2.5 py-1 rounded-lg border border-emerald-500/20 text-xs">
                      {t.replacement_token}
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 2: Facts */}
      {activeTab === 'facts' && (
        <div className="glass-card rounded-2xl overflow-hidden">
          <div className="p-4 border-b border-slate-800/60 flex items-center justify-between bg-slate-950/40">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Approved Claims & Substantiation Ledger
            </span>
            <span className="text-xs font-mono text-slate-400">{canon.facts.length} verified facts</span>
          </div>

          <div className="divide-y divide-slate-800/60">
            {canon.facts.map((f) => (
              <div key={f.fact_id} className="p-4 hover:bg-slate-800/30 transition-colors space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-indigo-400 bg-indigo-950/40 px-2 py-0.5 rounded border border-indigo-500/20">
                      {f.fact_id}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      f.status === 'CANONICAL'
                        ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/20'
                        : f.status === 'SUPERSEDED'
                        ? 'bg-red-500/15 text-red-300 border border-red-500/20'
                        : 'bg-purple-500/15 text-purple-300 border border-purple-500/20'
                    }`}>
                      {f.status}
                    </span>
                  </div>

                  {f.evidence_doc_url && (
                    <a
                      href={f.evidence_doc_url}
                      target="_blank"
                      rel="noreferrer"
                      className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-mono text-[11px]"
                    >
                      <ExternalLink className="w-3 h-3" />
                      Verification Proof
                    </a>
                  )}
                </div>

                <p className="text-slate-200 font-medium leading-relaxed">{f.claim_assertion}</p>

                {f.required_disclaimer_text && (
                  <div className="bg-slate-950/80 p-2.5 rounded-lg border border-amber-500/20 text-[11px] text-amber-300 font-mono">
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Required Disclaimer:</span>
                    {f.required_disclaimer_text}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Visuals */}
      {activeTab === 'visuals' && (
        <div className="glass-card rounded-2xl p-6 space-y-6">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-white">Visual Design Tokens & Relative Luminance</h3>
            <p className="text-xs text-slate-400">
              CIE L*a*b* space values calculated using CIEDE2000 ΔE00 and W3C IEC 61966-2-1 luminance formulas.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {canon.visuals.map((v) => (
              <div key={v.token_name} className="glass-card rounded-xl p-4 space-y-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-12 h-12 rounded-xl border border-slate-700 shadow-md flex-shrink-0"
                    style={{ backgroundColor: v.hex }}
                  />
                  <div>
                    <div className="text-xs font-bold text-white">{v.token_name}</div>
                    <div className="font-mono text-xs text-slate-400">{v.hex}</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] pt-2 border-t border-slate-800/60">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Role</span>
                    <span className="text-slate-200 font-semibold">{v.role}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">WCAG Luminance</span>
                    <span className="font-mono text-indigo-400 font-semibold">{v.wcag_luminance}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Logo Geometry Rule Card */}
          <div className="glass-card rounded-xl p-5 flex flex-wrap items-center justify-between gap-4 text-xs">
            <div className="space-y-1">
              <span className="font-bold text-white text-sm">Logo Geometric Constraints</span>
              <p className="text-slate-400">
                Aspect ratio locked to {canon.logo_rules.canonical_aspect_ratio.toFixed(2)}:1. Clear-space margin minimum: {canon.logo_rules.min_clear_space_margin}.
              </p>
            </div>
            <span className="font-mono px-3 py-1.5 rounded-lg bg-indigo-500/15 text-indigo-300 border border-indigo-500/20 font-bold">
              Tolerance: ±0.02
            </span>
          </div>
        </div>
      )}

      {/* Tab 4: Voice */}
      {activeTab === 'voice' && (
        <div className="glass-card rounded-2xl p-6 space-y-4 text-xs">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-white">{canon.voice.persona_name}</h3>
            <p className="text-slate-400">Target editorial profile and linguistic tolerances.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/60 space-y-1.5">
              <span className="text-slate-400 block font-semibold text-[11px]">Flesch-Kincaid Reading Grade Level:</span>
              <span className="text-xl font-bold text-white font-mono">
                {canon.voice.flesch_kincaid_range[0]} – {canon.voice.flesch_kincaid_range[1]}
              </span>
              <p className="text-[10px] text-slate-500">Accessible to undergraduate & enterprise readership</p>
            </div>
            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/60 space-y-1.5">
              <span className="text-slate-400 block font-semibold text-[11px]">Passive Voice Construction Ceiling:</span>
              <span className="text-xl font-bold text-white font-mono">
                {canon.voice.passive_voice_ceiling}
              </span>
              <p className="text-[10px] text-slate-500">Maintains direct, accountable brand voice</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
