import React, { useState } from 'react';
import { X, AlertTriangle, Send, HelpCircle, Sparkles, ShieldCheck } from 'lucide-react';
import { Finding, Role } from '../types';

interface OverrideModalProps {
  finding: Finding | null;
  actorRole: Role;
  onClose: () => void;
  onSubmitOverride: (findingId: string, reason: string, note: string) => void;
}

export const OverrideModal: React.FC<OverrideModalProps> = ({
  finding,
  actorRole,
  onClose,
  onSubmitOverride,
}) => {
  const [reason, setReason] = useState<string>('UNCLEAR_GUIDELINE');
  const [note, setNote] = useState<string>('');

  if (!finding) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitOverride(
      finding.finding_id,
      reason,
      note || `Overridden by ${actorRole} with reason: ${reason}`
    );
  };

  const reasonOptions = [
    {
      id: 'UNCLEAR_GUIDELINE',
      title: 'Guideline is Unclear or Contradictory',
      subtitle: 'Feeds into our Ambiguity Detection Engine (GAS)',
      icon: HelpCircle,
      activeColor: 'border-amber-500 bg-amber-500/10 text-amber-300',
    },
    {
      id: 'INTENTIONAL_STYLE',
      title: 'Intentional Style & Tone Choice',
      subtitle: 'Deliberate creative license or rhetorical nuance',
      icon: Sparkles,
      activeColor: 'border-blue-500 bg-blue-500/10 text-blue-300',
    },
    {
      id: 'APPROVED_EXCEPTION',
      title: 'Pre-Approved Campaign Exception',
      subtitle: 'Signed off by Executive or Legal Council',
      icon: ShieldCheck,
      activeColor: 'border-emerald-500 bg-emerald-500/10 text-emerald-300',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-overlay-in">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden animate-scale-in">
        {/* Accent top stripe */}
        <div className="h-1 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-400" />

        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5 text-amber-400">
            <div className="p-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-semibold text-white text-sm">Reviewer Override Protocol</h3>
              <p className="text-[11px] text-slate-400">Logged under role credentials: {actorRole}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="space-y-1.5">
            <span className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">
              Flagged Content Element
            </span>
            <div className="p-2.5 rounded-xl bg-slate-950/80 font-mono text-xs text-red-300 border border-red-500/20">
              {finding.original_span}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 block">
              Override Justification Category:
            </label>
            <div className="grid gap-2">
              {reasonOptions.map((opt) => {
                const Icon = opt.icon;
                const isSelected = reason === opt.id;
                return (
                  <div
                    key={opt.id}
                    onClick={() => setReason(opt.id)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
                      isSelected
                        ? opt.activeColor
                        : 'border-slate-800/80 bg-slate-950/40 hover:border-slate-700 text-slate-400'
                    }`}
                  >
                    <Icon className={`w-4 h-4 mt-0.5 flex-shrink-0 ${isSelected ? 'text-current' : 'text-slate-500'}`} />
                    <div className="flex-1">
                      <div className={`text-xs font-semibold ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                        {opt.title}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">{opt.subtitle}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 block">
              Auditor Justification Note:
            </label>
            <textarea
              rows={3}
              required
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Explain why this suggestion is being bypassed or exempted..."
              className="w-full bg-slate-950 border border-slate-800/80 rounded-xl p-3 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500/60 resize-none transition-colors"
            />
          </div>

          {reason === 'UNCLEAR_GUIDELINE' && (
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-300/90 leading-relaxed">
              <strong>Telemetry Impact:</strong> Selecting 'Unclear Guideline' registers friction against rule{' '}
              <span className="font-mono">{finding.rule_id}</span> and updates the Guideline Ambiguity Score (GAS) in real time.
            </div>
          )}

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-xs font-bold text-white flex items-center gap-1.5 shadow-lg shadow-amber-600/20 transition-all hover:scale-[1.02]"
            >
              <Send className="w-3.5 h-3.5" />
              Commit Override
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
