import React, { useState } from 'react';
import { Eye, Palette, Check, Sparkles, Maximize2, AlertCircle } from 'lucide-react';
import { Finding, VisualMeta } from '../types';

interface VisualProofingCanvasProps {
  visualMeta: VisualMeta | null;
  findings: Finding[];
  onApplyTokenFix: (findingId: string, resolvedHex: string) => void;
  onSelectFinding: (finding: Finding) => void;
}

export const VisualProofingCanvas: React.FC<VisualProofingCanvasProps> = ({
  visualMeta,
  findings,
  onApplyTokenFix,
  onSelectFinding,
}) => {
  const [selectedPin, setSelectedPin] = useState<string | null>(null);

  const paletteFinding = findings.find((f) => f.rule_id === 'RULE-PALETTE-DRIFT' && f.status === 'PENDING');
  const logoArFinding = findings.find((f) => f.rule_id === 'RULE-LOGO-ASPECT-RATIO' && f.status === 'PENDING');
  const logoClearSpaceFinding = findings.find((f) => f.rule_id === 'RULE-LOGO-CLEAR-SPACE' && f.status === 'PENDING');
  const contrastFinding = findings.find((f) => f.rule_id === 'RULE-WCAG-CONTRAST' && f.status === 'PENDING');

  const [currentBannerColor, setCurrentBannerColor] = useState<string>(
    visualMeta?.extracted_colors[1]?.hex || '#2563EB'
  );
  const [currentTextColor, setCurrentTextColor] = useState<string>(
    visualMeta?.color_pairs[0]?.fg || '#60A5FA'
  );
  const [isLogoFixed, setIsLogoFixed] = useState<boolean>(false);

  const handleApplyAutoContrast = () => {
    if (contrastFinding && contrastFinding.auto_resolved_token) {
      setCurrentTextColor(contrastFinding.auto_resolved_token.hex);
      onApplyTokenFix(contrastFinding.finding_id, contrastFinding.auto_resolved_token.hex);
    }
  };

  const handleSnapPaletteColor = () => {
    if (paletteFinding && paletteFinding.suggested_diff) {
      setCurrentBannerColor(paletteFinding.suggested_diff);
      onApplyTokenFix(paletteFinding.finding_id, paletteFinding.suggested_diff);
    }
  };

  const handleFixLogoGeometry = () => {
    setIsLogoFixed(true);
    if (logoArFinding) onApplyTokenFix(logoArFinding.finding_id, 'RESTORE_ASPECT_RATIO');
    if (logoClearSpaceFinding) onApplyTokenFix(logoClearSpaceFinding.finding_id, 'RESTORE_CLEAR_SPACE');
  };

  const activeIssueCount = (paletteFinding ? 1 : 0) + (logoArFinding ? 1 : 0) + (contrastFinding ? 1 : 0);

  return (
    <div className="glass-card rounded-2xl p-5 space-y-4">
      {/* Toolbar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800/60">
        <div className="flex items-center gap-2">
          <Eye className="w-4 h-4 text-indigo-400" />
          <span className="text-sm font-semibold text-white">Live Banner Preview</span>
          <span className="text-xs px-2 py-0.5 rounded bg-slate-800/60 text-slate-400 font-mono">
            {visualMeta?.dimensions.width || 1200} × {visualMeta?.dimensions.height || 630}
          </span>
        </div>
        {activeIssueCount > 0 && (
          <span className="text-xs px-2.5 py-1 rounded-full bg-red-500/15 text-red-300 font-medium border border-red-500/20">
            {activeIssueCount} visual {activeIssueCount === 1 ? 'issue' : 'issues'}
          </span>
        )}
      </div>

      {/* Banner */}
      <div
        className="relative rounded-xl overflow-hidden border border-slate-300/20 shadow-2xl min-h-[340px] flex flex-col justify-between p-8 transition-colors duration-500"
        style={{ backgroundColor: '#F8FAFC' }}
      >
        {/* Top row */}
        <div className="flex items-start justify-between z-10">
          {/* Logo */}
          <div className="relative group">
            <div
              className={`transition-all duration-500 rounded flex items-center justify-center font-bold tracking-tight text-white ${
                isLogoFixed
                  ? 'w-[200px] h-[50px] bg-[#1D4ED8] shadow-md border-2 border-emerald-400/50'
                  : 'w-[120px] h-[50px] bg-[#1D4ED8] shadow-md border-2 border-red-400/60'
              }`}
            >
              <span className="text-sm">Inkloom AI</span>
            </div>

            {/* Clear-space overlay */}
            {!isLogoFixed && (
              <div className="absolute -inset-2 border-2 border-dashed border-red-400/50 bg-red-500/5 rounded pointer-events-none">
                <span className="absolute -top-5 left-0 text-[9px] font-mono bg-red-500 text-white px-1.5 py-0.5 rounded shadow-sm">
                  Clear-space violation
                </span>
              </div>
            )}

            {/* Pin 1 */}
            {!isLogoFixed && logoArFinding && (
              <button
                onClick={() => onSelectFinding(logoArFinding)}
                className="absolute -top-3 -right-3 w-7 h-7 rounded-full bg-red-500 text-white flex items-center justify-center text-xs font-bold shadow-lg shadow-red-500/30 animate-pulse hover:scale-110 transition-transform"
              >
                1
              </button>
            )}
          </div>

          {/* Accent badge */}
          <div
            className="px-4 py-2 rounded-full text-xs font-semibold text-white shadow-sm transition-all duration-500"
            style={{ backgroundColor: currentBannerColor }}
          >
            Enterprise Governance Suite
          </div>

          {/* Pin 2 */}
          {paletteFinding && (
            <button
              onClick={() => onSelectFinding(paletteFinding)}
              className="absolute top-7 right-7 w-7 h-7 rounded-full bg-amber-500 text-white flex items-center justify-center text-xs font-bold shadow-lg shadow-amber-500/30 hover:scale-110 transition-transform"
              style={{ animation: 'float 2s ease-in-out infinite' }}
            >
              2
            </button>
          )}
        </div>

        {/* Content */}
        <div className="my-6 space-y-3 z-10 max-w-xl">
          <h2 className="text-2xl font-black text-slate-900 tracking-tight leading-tight">
            The Manuscript Operating System for High-Trust Publishing
          </h2>
          <div className="relative inline-block">
            <p
              className="text-base font-semibold transition-colors duration-500"
              style={{ color: currentTextColor }}
            >
              Deterministic sub-50ms verification with mathematically grounded intent preservation.
            </p>
            {/* Pin 3 */}
            {contrastFinding && (
              <button
                onClick={() => onSelectFinding(contrastFinding)}
                className="absolute -top-2 -right-4 w-7 h-7 rounded-full bg-red-500 text-white flex items-center justify-center text-xs font-bold shadow-lg shadow-red-500/30 animate-pulse hover:scale-110 transition-transform"
              >
                3
              </button>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between text-xs font-medium text-slate-500 border-t border-slate-200 pt-3 z-10">
          <span>inkloom.ai/enterprise</span>
          <span className="text-[10px] text-slate-400">Audited by LoomGuard</span>
        </div>
      </div>

      {/* 1-Click Fix Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Contrast Fix */}
        <div className="glass-card rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-200">Text Contrast</span>
            <span className={`text-[11px] font-mono font-semibold ${contrastFinding ? 'text-red-400' : 'text-emerald-400'}`}>
              {contrastFinding ? '2.43:1 ✗' : '6.41:1 ✓'}
            </span>
          </div>
          {contrastFinding ? (
            <>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1">
                  <div className="w-6 h-6 rounded border border-slate-600" style={{ backgroundColor: '#60A5FA' }} />
                  <span className="text-[10px] text-slate-500">→</span>
                  <div className="w-6 h-6 rounded border border-emerald-500/40" style={{ backgroundColor: '#1D4ED8' }} />
                </div>
                <span className="text-[10px] text-slate-400">WCAG AA compliant</span>
              </div>
              <button onClick={handleApplyAutoContrast} className="w-full py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-xs font-semibold text-white flex items-center justify-center gap-1.5 transition-all hover:scale-[1.02] shadow-md shadow-blue-600/15">
                <Sparkles className="w-3.5 h-3.5" />
                Fix Contrast
              </button>
            </>
          ) : (
            <div className="flex items-center gap-1.5 text-xs text-emerald-400">
              <Check className="w-3.5 h-3.5" /> Resolved
            </div>
          )}
        </div>

        {/* Palette Fix */}
        <div className="glass-card rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-200">Color Accuracy</span>
            <span className={`text-[11px] font-mono font-semibold ${paletteFinding ? 'text-amber-400' : 'text-emerald-400'}`}>
              {paletteFinding ? 'Off-brand' : 'On-brand ✓'}
            </span>
          </div>
          {paletteFinding ? (
            <>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1">
                  <div className="w-6 h-6 rounded border border-slate-600" style={{ backgroundColor: '#2563EB' }} />
                  <span className="text-[10px] text-slate-500">→</span>
                  <div className="w-6 h-6 rounded border border-emerald-500/40" style={{ backgroundColor: '#1D4ED8' }} />
                </div>
                <span className="text-[10px] text-slate-400">Brand-approved blue</span>
              </div>
              <button onClick={handleSnapPaletteColor} className="w-full py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white flex items-center justify-center gap-1.5 transition-all hover:scale-[1.02] shadow-md shadow-indigo-600/15">
                <Palette className="w-3.5 h-3.5" />
                Align Color
              </button>
            </>
          ) : (
            <div className="flex items-center gap-1.5 text-xs text-emerald-400">
              <Check className="w-3.5 h-3.5" /> Resolved
            </div>
          )}
        </div>

        {/* Logo Fix */}
        <div className="glass-card rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-200">Logo Shape</span>
            <span className={`text-[11px] font-mono font-semibold ${!isLogoFixed ? 'text-red-400' : 'text-emerald-400'}`}>
              {!isLogoFixed ? 'Distorted' : 'Correct ✓'}
            </span>
          </div>
          {!isLogoFixed ? (
            <>
              <p className="text-[11px] text-slate-400">Logo is squashed and margin is too tight</p>
              <button onClick={handleFixLogoGeometry} className="w-full py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white flex items-center justify-center gap-1.5 transition-all hover:scale-[1.02] shadow-md shadow-emerald-600/15">
                <Check className="w-3.5 h-3.5" />
                Restore Logo
              </button>
            </>
          ) : (
            <div className="flex items-center gap-1.5 text-xs text-emerald-400">
              <Check className="w-3.5 h-3.5" /> Resolved
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
