import React from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Unlock, 
  Users, 
  BookOpen, 
  BarChart3, 
  FileCheck,
  Shield
} from 'lucide-react';
import { Role } from '../types';

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  currentRole: Role;
  setCurrentRole: (role: Role) => void;
  airGapped: boolean;
  toggleAirGapped: () => void;
  readinessScore: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  currentRole,
  setCurrentRole,
  airGapped,
  toggleAirGapped,
  readinessScore,
}) => {
  const roles: { role: Role; label: string }[] = [
    { role: 'CREATOR', label: 'Content Creator' },
    { role: 'BRAND_MANAGER', label: 'Brand Manager' },
    { role: 'LEGAL_COMPLIANCE', label: 'Legal & Compliance' },
    { role: 'GOVERNANCE_ADMIN', label: 'Admin' },
  ];

  const tabs = [
    { id: 'proofing', label: 'Check My Draft', icon: FileCheck },
    { id: 'canon', label: 'Brand Canon', icon: BookOpen },
    { id: 'analytics', label: 'Ambiguity Insights', icon: BarChart3 },
    { id: 'confidentiality', label: 'Privacy Shield', icon: Shield },
  ];

  // SVG ring calculations
  const radius = 18;
  const circumference = 2 * Math.PI * radius;
  const progress = Math.min(100, Math.max(0, readinessScore));
  const dashOffset = circumference - (progress / 100) * circumference;
  const ringColor = progress > 80 ? '#10B981' : progress > 50 ? '#F59E0B' : '#EF4444';

  return (
    <header className="glass-header sticky top-0 z-50">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-indigo-500 to-blue-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-white">LoomGuard</span>
              <p className="text-[10px] text-slate-400 -mt-0.5">by Inkloom AI</p>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex items-center gap-0.5 bg-slate-900/60 p-1 rounded-xl border border-slate-800/60">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = currentTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setCurrentTab(tab.id)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-[13px] font-medium transition-all duration-200 ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {tab.label}
                </button>
              );
            })}
          </nav>

          {/* Right section */}
          <div className="flex items-center gap-3">
            {/* Air-Gapped Toggle */}
            <button
              onClick={toggleAirGapped}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all duration-200 ${
                airGapped
                  ? 'bg-amber-500/10 text-amber-300 border-amber-500/30 hover:bg-amber-500/15'
                  : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/15'
              }`}
            >
              {airGapped ? (
                <>
                  <Lock className="w-3.5 h-3.5" />
                  <span>Data stays local</span>
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                </>
              ) : (
                <>
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Cloud-assisted</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                </>
              )}
            </button>

            {/* Role Selector */}
            <div className="flex items-center gap-1.5 bg-slate-900/60 border border-slate-800/60 px-2.5 py-1.5 rounded-lg">
              <Users className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={currentRole}
                onChange={(e) => setCurrentRole(e.target.value as Role)}
                className="bg-transparent text-xs text-slate-200 font-medium focus:outline-none cursor-pointer"
              >
                {roles.map((r) => (
                  <option key={r.role} value={r.role} className="bg-slate-900 text-slate-200">
                    {r.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Readiness Ring */}
            <div className="relative flex items-center justify-center" title={`Publication readiness: ${progress}%`}>
              <svg width="44" height="44" viewBox="0 0 44 44">
                <circle className="readiness-ring-bg" cx="22" cy="22" r={radius} />
                <circle
                  className="readiness-ring-fill"
                  cx="22" cy="22" r={radius}
                  stroke={ringColor}
                  strokeDasharray={circumference}
                  strokeDashoffset={dashOffset}
                />
              </svg>
              <span className="absolute text-[11px] font-bold text-white">{progress}</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
