import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles, 
  RefreshCw,
  ArrowRight,
  ChevronDown,
  ChevronUp,
  HelpCircle,
  TrendingUp,
  Check,
  X
} from 'lucide-react';
import { TelemetrySummary, GuidelineTelemetryRecord } from '../types';

export const AmbiguityDashboard: React.FC = () => {
  const [telemetry, setTelemetry] = useState<TelemetrySummary | null>(null);
  const [selectedRule, setSelectedRule] = useState<GuidelineTelemetryRecord | null>(null);
  const [refinerDiff, setRefinerDiff] = useState<any | null>(null);
  const [isRefining, setIsRefining] = useState<boolean>(false);
  const [showFormula, setShowFormula] = useState<boolean>(false);

  const fetchTelemetry = async () => {
    try {
      const res = await fetch('/api/v1/ambiguity/telemetry');
      if (res.ok) {
        const data = await res.json();
        setTelemetry(data);
        if (data.telemetry_records?.length > 0) {
          setSelectedRule(data.telemetry_records[0]);
        }
      }
    } catch (e) {
      console.error('Failed to load telemetry', e);
    }
  };

  useEffect(() => {
    fetchTelemetry();
  }, []);

  const handleTriggerCanonRefiner = async (ruleId: string) => {
    setIsRefining(true);
    try {
      const res = await fetch('/api/v1/ambiguity/canon-refiner', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rule_id: ruleId }),
      });
      if (res.ok) {
        const diffData = await res.json();
        setRefinerDiff(diffData);
      }
    } catch (e) {
      console.error('Refiner call failed', e);
    } finally {
      setIsRefining(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Hero Header */}
      <div className="glass-card rounded-2xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-lg shadow-amber-500/15">
              <BarChart3 className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">
                Where are your brand guidelines failing?
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                We mathematically separate creator mistakes from unclear guidelines
              </p>
            </div>
          </div>

          <button
            onClick={fetchTelemetry}
            className="px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 text-xs text-slate-300 flex items-center gap-1.5 transition-colors border border-slate-700/60"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Refresh
          </button>
        </div>

        {/* How it works - expandable */}
        <button
          onClick={() => setShowFormula(!showFormula)}
          className="flex items-center gap-1.5 text-xs text-indigo-400 hover:text-indigo-300 transition-colors font-medium"
        >
          <HelpCircle className="w-3.5 h-3.5" />
          How does the Ambiguity Score work?
          {showFormula ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
        </button>

        {showFormula && (
          <div className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-4 space-y-2 animate-fade-in-up">
            <div className="text-amber-300 font-mono text-sm font-semibold">
              GAS = ln(1 + triggers) × [ 0.5 × override_rate + 0.3 × dispute_rate + 0.2 × resolution_delay ]
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              A high score means team members frequently disagree about a rule — indicating the guideline itself is unclear.
              A low score means the rule is clear but creators keep making the same mistake — indicating a training need.
            </p>
          </div>
        )}
      </div>

      {/* Comparison Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Card 1: Clear Rule */}
        <div className="glass-card rounded-2xl overflow-hidden animate-fade-in-up stagger-1">
          <div className="h-1 bg-emerald-500" />
          <div className="p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Clear Rule, Simple Fix</span>
              </div>
              <span className="text-2xl font-bold text-emerald-400 font-mono">0.22</span>
            </div>

            <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800/60">
              <div className="text-xs font-semibold text-white">Standard Mark Casing</div>
              <div className="text-[11px] text-slate-400 mt-0.5">"Inkloom AI" not "InkLoom" — simple typo rule</div>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="bg-slate-950/40 p-2.5 rounded-lg">
                <span className="text-slate-400 text-[10px] block">Triggers</span>
                <span className="font-mono font-bold text-white text-sm">40</span>
              </div>
              <div className="bg-slate-950/40 p-2.5 rounded-lg">
                <span className="text-slate-400 text-[10px] block">Override rate</span>
                <span className="font-mono font-bold text-emerald-400">7.5%</span>
                <div className="mt-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 rounded-full" style={{ width: '7.5%' }} />
                </div>
              </div>
              <div className="bg-slate-950/40 p-2.5 rounded-lg">
                <span className="text-slate-400 text-[10px] block">Avg resolve</span>
                <span className="font-mono font-bold text-white">1.5 hrs</span>
              </div>
            </div>

            <div className="bg-emerald-950/20 border border-emerald-500/15 p-3 rounded-xl text-xs text-emerald-300">
              <div className="font-semibold flex items-center gap-1 mb-1">
                <CheckCircle2 className="w-3 h-3" /> Recommendation
              </div>
              <p className="text-[11px] text-emerald-200/80 leading-relaxed">
                Enable auto-fix for this rule. Creators recognize the typo immediately.
              </p>
            </div>
          </div>
        </div>

        {/* Card 2: Confusing Guideline */}
        <div className="glass-card rounded-2xl overflow-hidden glow-amber animate-fade-in-up stagger-2">
          <div className="h-1 bg-amber-500" />
          <div className="p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Confusing Guideline</span>
              </div>
              <div className="text-right">
                <span className="text-2xl font-bold text-amber-400 font-mono">2.22</span>
                <span className="text-[10px] text-amber-400/70 block">10× higher!</span>
              </div>
            </div>

            <div className="bg-slate-950/60 p-3 rounded-lg border border-amber-500/20">
              <div className="text-xs font-semibold text-white">Bold Challenger Tone + Humble Understatement</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Contradictory voice instructions cause team debates</div>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="bg-slate-950/40 p-2.5 rounded-lg">
                <span className="text-slate-400 text-[10px] block">Triggers</span>
                <span className="font-mono font-bold text-white text-sm">35</span>
              </div>
              <div className="bg-slate-950/40 p-2.5 rounded-lg">
                <span className="text-slate-400 text-[10px] block">Override rate</span>
                <span className="font-mono font-bold text-red-400">62.9%</span>
                <div className="mt-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-red-500 rounded-full" style={{ width: '62.9%' }} />
                </div>
              </div>
              <div className="bg-slate-950/40 p-2.5 rounded-lg">
                <span className="text-slate-400 text-[10px] block">Avg resolve</span>
                <span className="font-mono font-bold text-amber-400">36 hrs</span>
              </div>
            </div>

            <div className="bg-amber-950/20 border border-amber-500/15 p-3 rounded-xl text-xs space-y-2">
              <div className="font-semibold text-amber-300 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> High friction detected
              </div>
              <p className="text-[11px] text-amber-200/80 leading-relaxed">
                22 overrides and 18 dispute comments. The guideline itself needs rewriting.
              </p>
              <button
                onClick={() => handleTriggerCanonRefiner('RULE-VOICE-002')}
                disabled={isRefining}
                className="w-full py-2 px-3 rounded-lg bg-amber-600 hover:bg-amber-500 text-xs font-bold text-white flex items-center justify-center gap-1.5 shadow-md shadow-amber-600/20 transition-all hover:scale-[1.02] disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {isRefining ? 'Analyzing 22 override notes...' : 'Generate Clearer Guideline'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Canon Refiner Output */}
      {refinerDiff && (
        <div className="glass-card rounded-2xl overflow-hidden glow-blue animate-scale-in">
          <div className="h-1 bg-gradient-to-r from-blue-500 to-indigo-500" />
          <div className="p-6 space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-blue-400" />
                <h3 className="text-base font-bold text-white">Proposed Guideline Improvement</h3>
              </div>
              <span className="text-xs px-2.5 py-0.5 rounded bg-emerald-500/15 text-emerald-300 font-mono border border-emerald-500/20">
                {refinerDiff.estimated_gas_reduction}
              </span>
            </div>

            {/* Synthesized feedback */}
            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/60 text-xs text-slate-300 leading-relaxed">
              <span className="text-slate-400 text-[11px] font-medium block mb-1">Summary of team feedback:</span>
              {refinerDiff.synthesized_feedback}
            </div>

            {/* Before → After */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-red-950/10 p-4 rounded-xl border border-red-500/20 space-y-2">
                <span className="text-[11px] text-red-400 font-semibold uppercase flex items-center gap-1">
                  <X className="w-3 h-3" /> Current (Ambiguous)
                </span>
                <p className="text-xs text-red-200/80 leading-relaxed">{refinerDiff.original_guideline}</p>
              </div>
              <div className="bg-emerald-950/10 p-4 rounded-xl border border-emerald-500/20 space-y-2">
                <span className="text-[11px] text-emerald-400 font-semibold uppercase flex items-center gap-1">
                  <Check className="w-3 h-3" /> Proposed (Clear)
                </span>
                <p className="text-xs text-emerald-200/80 leading-relaxed">{refinerDiff.proposed_clarified_guideline}</p>
              </div>
            </div>

            {/* Do / Don't */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
                  <Check className="w-3 h-3" /> Do
                </span>
                {refinerDiff.do_examples.map((ex: string, i: number) => (
                  <div key={i} className="text-[11px] text-emerald-200/80 font-mono bg-emerald-950/10 p-2.5 rounded-lg border border-emerald-500/10">
                    {ex}
                  </div>
                ))}
              </div>
              <div className="space-y-2">
                <span className="text-[11px] text-red-400 font-bold flex items-center gap-1">
                  <X className="w-3 h-3" /> Don't
                </span>
                {refinerDiff.dont_examples.map((ex: string, i: number) => (
                  <div key={i} className="text-[11px] text-red-200/80 font-mono bg-red-950/10 p-2.5 rounded-lg border border-red-500/10">
                    {ex}
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => alert("Guideline Upgrade Diff committed to Brand Canon v3.3.0!")}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-xs font-bold text-white shadow-lg shadow-blue-600/20 transition-all hover:scale-[1.02]"
              >
                Commit to Canon v3.3
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
