import React, { useState } from 'react';
import { 
  Play, 
  RotateCcw, 
  Check, 
  FileText, 
  Eye, 
  Sparkles, 
  Cpu, 
  CheckCircle2, 
  AlertTriangle, 
  Zap, 
  Clock,
  Search,
  ArrowRight,
  XCircle,
  ShieldAlert,
  Type,
  MessageSquare,
  Scale,
  Palette,
  Accessibility,
  Lock
} from 'lucide-react';
import { Finding, AuditResponse, VisualMeta, Role } from '../types';
import { VisualProofingCanvas } from './VisualProofingCanvas';

interface ProofingStudioProps {
  auditData: AuditResponse | null;
  onRunAudit: (content: string, visualMeta: VisualMeta) => void;
  onAcceptDiff: (findingId: string) => void;
  onOpenOverrideModal: (finding: Finding) => void;
  onOpenTraceDrawer: (finding: Finding) => void;
  isLoading: boolean;
  currentRole: Role;
}

export const ProofingStudio: React.FC<ProofingStudioProps> = ({
  auditData,
  onRunAudit,
  onAcceptDiff,
  onOpenOverrideModal,
  onOpenTraceDrawer,
  isLoading,
  currentRole,
}) => {
  const [activeView, setActiveView] = useState<'document' | 'visual'>('document');
  const [selectedPillarFilter, setSelectedPillarFilter] = useState<string>('ALL');

  const [docContent, setDocContent] = useState<string>(
    auditData?.original_content ||
      `# Announcing InkLoom Studio: The Next Era of Brand Governance\n\n` +
      `Today we are thrilled to unveil InkLoom Studio, our enterprise publication platform. ` +
      `Built under the confidential initiative Project Chronos, our new engine replaces your entire ` +
      `legal team with 100% accuracy, eliminating every compliance bottleneck overnight.\n\n` +
      `Inkloom AI verification executes Stage 1 deterministic passes in under 50 milliseconds. ` +
      `The Enterprise plan is available starting today at $49 per user monthly billed annually. ` +
      `Delve into our documentation to harness the power of seamless brand compliance.\n\n` +
      `<div class="cta-banner">\n` +
      `  <p>Learn more about our governance architecture: <a href="#">click here</a></p>\n` +
      `  <img src="brand_mark.png" alt="image" />\n` +
      `</div>`
  );

  const [visualMeta, setVisualMeta] = useState<VisualMeta>({
    asset_name: "Hero_Promotional_Banner_Q1.png",
    dimensions: { width: 1200, height: 630 },
    extracted_colors: [
      { name: "Background", hex: "#F8FAFC" },
      { name: "Primary Banner Accent", hex: "#2563EB" },
    ],
    color_pairs: [
      {
        fg: "#60A5FA",
        bg: "#F8FAFC",
        element_name: "Hero Subtitle Text",
        is_large: false,
      },
    ],
    logo_box: {
      width: 120.0,
      height: 50.0,
      adjacent_text_dist: 4.5,
    },
  });

  const handleApplyFix = (finding: Finding) => {
    if (finding.suggested_diff && docContent.includes(finding.original_span)) {
      setDocContent((prev) => prev.replace(finding.original_span, finding.suggested_diff!));
    }
    onAcceptDiff(finding.finding_id);
  };

  const handleLoadDemoPacket = () => {
    const demoText = 
      `# Announcing InkLoom Studio: The Next Era of Brand Governance\n\n` +
      `Today we are thrilled to unveil InkLoom Studio, our enterprise publication platform. ` +
      `Built under the confidential initiative Project Chronos, our new engine replaces your entire ` +
      `legal team with 100% accuracy, eliminating every compliance bottleneck overnight.\n\n` +
      `Inkloom AI verification executes Stage 1 deterministic passes in under 50 milliseconds. ` +
      `The Enterprise plan is available starting today at $49 per user monthly billed annually. ` +
      `Delve into our documentation to harness the power of seamless brand compliance.\n\n` +
      `<div class="cta-banner">\n` +
      `  <p>Learn more about our governance architecture: <a href="#">click here</a></p>\n` +
      `  <img src="brand_mark.png" alt="image" />\n` +
      `</div>`;
    
    setDocContent(demoText);
    onRunAudit(demoText, visualMeta);
  };

  const findings = auditData?.findings || [];
  const filteredFindings = selectedPillarFilter === 'ALL'
    ? findings
    : findings.filter((f) => f.pillar === selectedPillarFilter);

  const pendingFindings = findings.filter((f) => f.status === 'PENDING');
  const resolvedFindings = findings.filter((f) => f.status === 'ACCEPTED' || f.status === 'OVERRIDDEN');

  const getSeverityStyle = (sev: string) => {
    switch (sev) {
      case 'CRITICAL': return { bg: 'bg-red-500/15', text: 'text-red-300', border: 'border-red-500/30', dot: 'bg-red-400' };
      case 'HIGH': return { bg: 'bg-orange-500/15', text: 'text-orange-300', border: 'border-orange-500/30', dot: 'bg-orange-400' };
      case 'MEDIUM': return { bg: 'bg-amber-500/15', text: 'text-amber-300', border: 'border-amber-500/30', dot: 'bg-amber-400' };
      case 'LOW': return { bg: 'bg-blue-500/15', text: 'text-blue-300', border: 'border-blue-500/30', dot: 'bg-blue-400' };
      default: return { bg: 'bg-slate-500/15', text: 'text-slate-300', border: 'border-slate-500/30', dot: 'bg-slate-400' };
    }
  };

  const getPillarInfo = (p: string) => {
    switch (p) {
      case 'TERMINOLOGY': return { label: 'Word Choice', icon: Type, borderClass: 'pillar-border-terminology', color: 'text-blue-400' };
      case 'VOICE': return { label: 'Tone & Voice', icon: MessageSquare, borderClass: 'pillar-border-voice', color: 'text-cyan-400' };
      case 'FACT_CLAIM': return { label: 'Claim Verification', icon: Scale, borderClass: 'pillar-border-fact', color: 'text-amber-400' };
      case 'VISUAL_GEOMETRY': return { label: 'Visual Check', icon: Palette, borderClass: 'pillar-border-visual', color: 'text-indigo-400' };
      case 'ACCESSIBILITY_WCAG': return { label: 'Accessibility', icon: Accessibility, borderClass: 'pillar-border-accessibility', color: 'text-emerald-400' };
      case 'CONFIDENTIALITY': return { label: 'Privacy', icon: Lock, borderClass: 'pillar-border-confidentiality', color: 'text-purple-400' };
      default: return { label: p, icon: Search, borderClass: '', color: 'text-slate-400' };
    }
  };

  // Pillar breakdown for the mini bar
  const pillarCounts = findings.reduce((acc, f) => {
    acc[f.pillar] = (acc[f.pillar] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  const totalFindings = findings.length || 1;
  const pillarColors: Record<string, string> = {
    'TERMINOLOGY': '#3B82F6', 'VOICE': '#06B6D4', 'FACT_CLAIM': '#F59E0B',
    'VISUAL_GEOMETRY': '#6366F1', 'ACCESSIBILITY_WCAG': '#10B981', 'CONFIDENTIALITY': '#8B5CF6',
  };

  return (
    <div className="space-y-5">
      {/* Action Bar */}
      <div className="glass-card rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={handleLoadDemoPacket}
            className="px-4 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-xs font-medium text-slate-200 border border-slate-700/60 flex items-center gap-2 transition-all hover:scale-[1.02]"
          >
            <RotateCcw className="w-3.5 h-3.5 text-indigo-400" />
            Load Demo (6 planted violations)
          </button>

          <button
            onClick={() => onRunAudit(docContent, visualMeta)}
            disabled={isLoading}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-sm font-bold text-white flex items-center gap-2 shadow-lg shadow-indigo-600/25 transition-all hover:scale-[1.02] disabled:opacity-50 disabled:hover:scale-100"
          >
            {isLoading ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Scanning all 6 pillars...
              </span>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                Run Pre-Publication Check
              </>
            )}
          </button>
        </div>

        {/* Results summary strip */}
        {auditData && (
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-5 text-xs">
              <div className="flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-slate-400">Deterministic scan:</span>
                <span className="font-mono text-emerald-300 font-semibold">{auditData.stage1_latency_ms}ms</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-blue-400" />
                <span className="text-slate-400">Total:</span>
                <span className="font-mono text-blue-300 font-semibold">{auditData.total_latency_ms}ms</span>
              </div>
            </div>

            {/* Issue count badge */}
            <div className="flex items-center gap-2 bg-slate-950/60 px-3 py-1.5 rounded-lg border border-slate-800/60">
              <span className="text-lg font-bold text-white animate-fade-in-up">{auditData.total_issues_count}</span>
              <span className="text-xs text-slate-400">issues found</span>
            </div>
          </div>
        )}
      </div>

      {/* Main Split Pane */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left: Document/Visual Editor */}
        <div className="lg:col-span-7 space-y-4">
          {/* View Switcher */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveView('document')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeView === 'document'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60 border border-slate-800/60'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              Document Draft
            </button>
            <button
              onClick={() => setActiveView('visual')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeView === 'visual'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60 border border-slate-800/60'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              Banner Preview
            </button>
          </div>

          {activeView === 'document' ? (
            <div className="glass-card rounded-2xl p-5 space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400 pb-2 border-b border-slate-800/60">
                <span className="font-medium text-slate-300">Press Release Draft</span>
                <span className="font-mono">{docContent.split(/\s+/).length} words</span>
              </div>

              <textarea
                value={docContent}
                onChange={(e) => setDocContent(e.target.value)}
                rows={16}
                className="w-full bg-slate-950/60 border border-slate-800/60 rounded-xl p-4 font-mono text-xs text-slate-200 focus:outline-none focus:border-indigo-500/50 leading-relaxed resize-y transition-colors"
              />

              {/* Pillar breakdown mini-bar */}
              {findings.length > 0 && (
                <div className="space-y-2">
                  <div className="text-[11px] text-slate-400 font-medium">Issues by category</div>
                  <div className="flex h-2 rounded-full overflow-hidden bg-slate-800/60">
                    {Object.entries(pillarCounts).map(([pillar, count]) => (
                      <div
                        key={pillar}
                        style={{
                          width: `${(count / totalFindings) * 100}%`,
                          backgroundColor: pillarColors[pillar] || '#64748B',
                        }}
                        className="transition-all duration-500"
                        title={`${getPillarInfo(pillar).label}: ${count}`}
                      />
                    ))}
                  </div>
                  <div className="flex flex-wrap gap-x-3 gap-y-1">
                    {Object.entries(pillarCounts).map(([pillar, count]) => {
                      const info = getPillarInfo(pillar);
                      return (
                        <div key={pillar} className="flex items-center gap-1 text-[10px] text-slate-400">
                          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: pillarColors[pillar] }} />
                          {info.label} ({count})
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <VisualProofingCanvas
              visualMeta={visualMeta}
              findings={findings}
              onApplyTokenFix={(fid, hex) => {
                const f = findings.find((x) => x.finding_id === fid);
                if (f) handleApplyFix(f);
              }}
              onSelectFinding={(f) => onOpenTraceDrawer(f)}
            />
          )}
        </div>

        {/* Right: Findings Panel */}
        <div className="lg:col-span-5 space-y-4">
          {/* Header & Filter */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-white">Issues</span>
              {pendingFindings.length > 0 && (
                <span className="text-xs px-2 py-0.5 rounded-full bg-red-500/15 text-red-300 border border-red-500/20 font-medium">
                  {pendingFindings.length} to fix
                </span>
              )}
              {resolvedFindings.length > 0 && (
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/20 font-medium">
                  {resolvedFindings.length} resolved
                </span>
              )}
            </div>

            <select
              value={selectedPillarFilter}
              onChange={(e) => setSelectedPillarFilter(e.target.value)}
              className="bg-slate-900/60 border border-slate-800/60 rounded-lg px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none cursor-pointer"
            >
              <option value="ALL">All categories</option>
              <option value="TERMINOLOGY">Word Choice</option>
              <option value="VOICE">Tone & Voice</option>
              <option value="FACT_CLAIM">Claim Verification</option>
              <option value="VISUAL_GEOMETRY">Visual Check</option>
              <option value="ACCESSIBILITY_WCAG">Accessibility</option>
              <option value="CONFIDENTIALITY">Privacy</option>
            </select>
          </div>

          {/* Finding Cards */}
          <div className="space-y-3 max-h-[720px] overflow-y-auto pr-1">
            {filteredFindings.length === 0 ? (
              <div className="glass-card rounded-xl p-8 text-center space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto animate-float" />
                <h4 className="text-sm font-semibold text-white">All clear!</h4>
                <p className="text-xs text-slate-400">No issues found in this category.</p>
              </div>
            ) : (
              filteredFindings.map((finding, idx) => {
                const pillarInfo = getPillarInfo(finding.pillar);
                const sevStyle = getSeverityStyle(finding.severity);
                const PillarIcon = pillarInfo.icon;
                const isResolved = finding.status === 'ACCEPTED' || finding.status === 'OVERRIDDEN';

                return (
                  <div
                    key={finding.finding_id}
                    className={`glass-card rounded-xl p-4 space-y-3 transition-all duration-300 animate-fade-in-up ${pillarInfo.borderClass} ${
                      isResolved ? 'opacity-60' : 'hover:border-slate-600/60'
                    } stagger-${Math.min(idx + 1, 6)}`}
                  >
                    {/* Card header */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <PillarIcon className={`w-3.5 h-3.5 ${pillarInfo.color}`} />
                        <span className="text-xs font-semibold text-slate-200">{pillarInfo.label}</span>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded font-semibold border ${sevStyle.bg} ${sevStyle.text} ${sevStyle.border}`}>
                          {finding.severity}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        {isResolved && (
                          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                            finding.status === 'ACCEPTED'
                              ? 'bg-emerald-500/15 text-emerald-300'
                              : 'bg-amber-500/15 text-amber-300'
                          }`}>
                            <Check className="w-2.5 h-2.5" />
                            {finding.status === 'ACCEPTED' ? 'Fixed' : 'Overridden'}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Explanation */}
                    <p className="text-xs text-slate-300 leading-relaxed">{finding.explanation}</p>

                    {/* Diff view */}
                    {finding.suggested_diff && finding.status === 'PENDING' && (
                      <div className="bg-slate-950/60 rounded-lg p-3 border border-slate-800/60 space-y-2">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-slate-400 font-medium">Suggested change:</span>
                          {finding.intent_preservation_score && (
                            <div className="flex items-center gap-1.5">
                              <span className="text-emerald-400 font-medium">
                                {Math.round(finding.intent_preservation_score * 100)}% meaning preserved
                              </span>
                              <div className="w-12 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-emerald-500 rounded-full transition-all"
                                  style={{ width: `${(finding.intent_preservation_score || 0) * 100}%` }}
                                />
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="font-mono text-xs space-y-1">
                          <div className="text-red-400/90 line-through bg-red-950/20 px-2.5 py-1.5 rounded">
                            {finding.original_span}
                          </div>
                          <div className="text-emerald-400 bg-emerald-950/20 px-2.5 py-1.5 rounded font-medium">
                            {finding.suggested_diff}
                          </div>
                        </div>

                        {finding.auto_resolved_token && (
                          <div className="flex items-center gap-2 text-[11px] text-blue-300 bg-blue-950/20 p-2 rounded border border-blue-500/15">
                            <div className="w-4 h-4 rounded" style={{ backgroundColor: finding.auto_resolved_token.hex }} />
                            <span>Auto-resolved to {finding.auto_resolved_token.token_name} ({finding.auto_resolved_token.hex})</span>
                            <span className="ml-auto font-mono">{finding.auto_resolved_token.contrast_ratio}:1</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Actions */}
                    {finding.status === 'PENDING' && (
                      <div className="flex items-center justify-between pt-1">
                        <button
                          onClick={() => onOpenTraceDrawer(finding)}
                          className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-medium transition-colors"
                        >
                          <Cpu className="w-3 h-3" />
                          Why was this flagged?
                        </button>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => onOpenOverrideModal(finding)}
                            className="px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 text-xs font-medium text-slate-300 border border-slate-700/60 transition-colors"
                          >
                            Override
                          </button>
                          <button
                            onClick={() => handleApplyFix(finding)}
                            className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white flex items-center gap-1.5 shadow-md shadow-emerald-600/15 transition-all hover:scale-[1.02]"
                          >
                            <Check className="w-3.5 h-3.5" />
                            Accept Fix
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
