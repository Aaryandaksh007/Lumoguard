export type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';

export type Pillar = 
  | 'TERMINOLOGY' 
  | 'VOICE' 
  | 'FACT_CLAIM' 
  | 'VISUAL_GEOMETRY' 
  | 'ACCESSIBILITY_WCAG' 
  | 'CONFIDENTIALITY';

export type Role = 'CREATOR' | 'BRAND_MANAGER' | 'LEGAL_COMPLIANCE' | 'GOVERNANCE_ADMIN';

export interface DiffChunk {
  type: 'equal' | 'removed' | 'added';
  text: string;
}

export interface ProvenanceData {
  engine: string;
  algorithm?: string;
  citation?: string;
  matched_fact_id?: string;
  evidence_url?: string;
  sanitized_payload_preview?: string;
  latency_ms: number;
  context_mode?: string;
  total_eval_latency_ms?: number;
  air_gapped_mode?: boolean;
}

export interface AutoResolvedToken {
  token_name: string;
  hex: string;
  contrast_ratio: number;
  delta_e00: number;
}

export interface Finding {
  finding_id: string;
  pillar: Pillar;
  rule_id: string;
  severity: Severity;
  verdict?: string;
  original_span: string;
  char_start?: number;
  char_end?: number;
  suggested_diff?: string;
  diff_chunks?: DiffChunk[];
  auto_resolved_token?: AutoResolvedToken;
  explanation: string;
  provenance: ProvenanceData;
  status: 'PENDING' | 'ACCEPTED' | 'REJECTED' | 'OVERRIDDEN';
  intent_preservation_score?: number;
}

export interface VisualMeta {
  asset_name: string;
  dimensions: { width: number; height: number };
  extracted_colors: Array<{ name: string; hex: string }>;
  color_pairs: Array<{ fg: string; bg: string; element_name?: string; is_large?: boolean }>;
  logo_box?: {
    width: number;
    height: number;
    adjacent_text_dist: number;
  };
}

export interface AuditResponse {
  audit_id: string;
  title: string;
  asset_type: string;
  original_content: string;
  scrubbed_content: string;
  token_map: Record<string, string>;
  total_issues_count: number;
  readiness_score: number;
  stage1_latency_ms: number;
  stage2_latency_ms: number;
  total_latency_ms: number;
  findings_by_pillar: Record<string, number>;
  findings_by_severity: Record<string, number>;
  findings: Finding[];
}

export interface GuidelineTelemetryRecord {
  rule_id: string;
  rule_name: string;
  pillar: string;
  triggers_count: number;
  overrides_count: number;
  override_rate_pct: number;
  disputes_count: number;
  dispute_rate_pct: number;
  mean_resolution_hours: number;
  gas_score: number;
  classification: 'HABITUAL_MISTAKE' | 'UNCLEAR_GUIDELINE' | 'INSUFFICIENT_DATA';
  recommendation: string;
}

export interface TelemetrySummary {
  total_rules_monitored: number;
  unclear_guidelines_count: number;
  habitual_mistakes_count: number;
  highest_friction_rule?: GuidelineTelemetryRecord;
  telemetry_records: GuidelineTelemetryRecord[];
}

export interface CanonOverview {
  canon_version: string;
  organization: string;
  last_updated: string;
  terms: Array<{
    term_id: string;
    surface_form: string;
    rule_type: string;
    replacement_token?: string;
    rationale_citation: string;
  }>;
  voice: {
    voice_id: string;
    persona_name: string;
    flesch_kincaid_range: [number, number];
    passive_voice_ceiling: string;
  };
  facts: Array<{
    fact_id: string;
    claim_assertion: string;
    status: string;
    evidence_doc_url?: string;
    required_disclaimer_text?: string;
  }>;
  visuals: Array<{
    token_name: string;
    hex: string;
    role: string;
    wcag_luminance: number;
  }>;
  logo_rules: {
    canonical_aspect_ratio: number;
    min_clear_space_margin: string;
  };
}

