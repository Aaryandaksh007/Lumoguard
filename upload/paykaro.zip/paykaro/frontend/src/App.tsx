import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ProofingStudio } from './components/ProofingStudio';
import { AmbiguityDashboard } from './components/AmbiguityDashboard';
import { BrandCanonView } from './components/BrandCanonView';
import { ConfidentialityInspector } from './components/ConfidentialityInspector';
import { ContextTraceDrawer } from './components/ContextTraceDrawer';
import { OverrideModal } from './components/OverrideModal';
import { AuditResponse, Finding, Role, VisualMeta } from './types';
import { Shield, Info, ExternalLink, Cpu, BookOpen, Lock } from 'lucide-react';

export const App: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<string>('proofing');
  const [currentRole, setCurrentRole] = useState<Role>('CREATOR');
  const [airGapped, setAirGapped] = useState<boolean>(false);
  const [auditData, setAuditData] = useState<AuditResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [showDisclosures, setShowDisclosures] = useState<boolean>(false);

  // Modal / Drawer states
  const [traceFinding, setTraceFinding] = useState<Finding | null>(null);
  const [overrideFinding, setOverrideFinding] = useState<Finding | null>(null);

  // Initial audit run on demo packet
  useEffect(() => {
    runInitialAudit();
  }, []);

  const runInitialAudit = async () => {
    setIsLoading(true);
    try {
      const demoRes = await fetch('/api/v1/audit/demo-packet');
      if (demoRes.ok) {
        const demoPacket = await demoRes.json();
        const auditRes = await fetch('/api/v1/audit/preflight', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: demoPacket.title,
            content: demoPacket.content,
            asset_type: demoPacket.asset_type,
            visual_meta: demoPacket.visual_meta,
            is_air_gapped: airGapped,
          }),
        });
        if (auditRes.ok) {
          const auditResult = await auditRes.json();
          setAuditData(auditResult);
        }
      }
    } catch (e) {
      console.error('Initial audit failed', e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRunAudit = async (content: string, visualMeta: VisualMeta) => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/v1/audit/preflight', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: 'User Pre-Publication Manuscript',
          content: content,
          asset_type: 'MARKDOWN',
          visual_meta: visualMeta,
          is_air_gapped: airGapped,
        }),
      });
      if (res.ok) {
        const result = await res.json();
        setAuditData(result);
      }
    } catch (e) {
      console.error('Audit run failed', e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAcceptDiff = async (findingId: string) => {
    try {
      const res = await fetch('/api/v1/suggestions/accept', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          finding_id: findingId,
          actor_role: currentRole,
        }),
      });
      if (res.ok) {
        setAuditData((prev) => {
          if (!prev) return null;
          return {
            ...prev,
            readiness_score: Math.min(100, prev.readiness_score + 15),
            findings: prev.findings.map((f) =>
              f.finding_id === findingId ? { ...f, status: 'ACCEPTED' as const } : f
            ),
          };
        });
      }
    } catch (e) {
      console.error('Accept diff failed', e);
    }
  };

  const handleSubmitOverride = async (findingId: string, reason: string, note: string) => {
    try {
      const res = await fetch('/api/v1/suggestions/override', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          finding_id: findingId,
          actor_role: currentRole,
          override_reason: reason,
          comment_text: note,
        }),
      });
      if (res.ok) {
        setOverrideFinding(null);
        setAuditData((prev) => {
          if (!prev) return null;
          return {
            ...prev,
            findings: prev.findings.map((f) =>
              f.finding_id === findingId ? { ...f, status: 'OVERRIDDEN' as const } : f
            ),
          };
        });
      }
    } catch (e) {
      console.error('Override commit failed', e);
    }
  };

  const toggleAirGapped = async () => {
    const nextState = !airGapped;
    setAirGapped(nextState);
    try {
      await fetch('/api/v1/confidentiality/toggle-privacy-lock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ air_gapped: nextState }),
      });
    } catch (e) {
      console.error('Toggle privacy lock failed', e);
    }
  };

  return (
    <div className="min-h-screen text-slate-100 flex flex-col font-sans selection:bg-indigo-600 selection:text-white">
      {/* Header */}
      <Header
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        currentRole={currentRole}
        setCurrentRole={setCurrentRole}
        airGapped={airGapped}
        toggleAirGapped={toggleAirGapped}
        readinessScore={auditData?.readiness_score || 0}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div key={currentTab} className="animate-fade-in-up">
          {currentTab === 'proofing' && (
            <ProofingStudio
              auditData={auditData}
              onRunAudit={handleRunAudit}
              onAcceptDiff={handleAcceptDiff}
              onOpenOverrideModal={(f) => setOverrideFinding(f)}
              onOpenTraceDrawer={(f) => setTraceFinding(f)}
              isLoading={isLoading}
              currentRole={currentRole}
            />
          )}

          {currentTab === 'analytics' && <AmbiguityDashboard />}

          {currentTab === 'canon' && <BrandCanonView />}

          {currentTab === 'confidentiality' && <ConfidentialityInspector />}
        </div>
      </main>

      {/* Context Trace Drawer */}
      <ContextTraceDrawer
        finding={traceFinding}
        onClose={() => setTraceFinding(null)}
      />

      {/* Override Policy Modal */}
      <OverrideModal
        finding={overrideFinding}
        actorRole={currentRole}
        onClose={() => setOverrideFinding(null)}
        onSubmitOverride={handleSubmitOverride}
      />

      {/* Footer */}
      <footer className="border-t border-slate-800/60 py-5 text-xs text-slate-500">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded-md bg-gradient-to-br from-indigo-600 to-blue-700 flex items-center justify-center">
              <Shield className="w-3.5 h-3.5 text-white" />
            </div>
            <span>
              <strong className="text-slate-300">LoomGuard</strong>
              <span className="text-slate-500 ml-1.5">Built for the Inkloom AI Brand Governance Challenge</span>
            </span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowDisclosures(true)}
              className="text-slate-400 hover:text-indigo-300 flex items-center gap-1.5 transition-colors"
            >
              <Info className="w-3.5 h-3.5" />
              Disclosures & Compliance
            </button>
            <span className="text-slate-600">|</span>
            <span className="text-slate-500 flex items-center gap-1">
              <Cpu className="w-3 h-3" />
              Hybrid Verification Engine
            </span>
          </div>
        </div>
      </footer>

      {/* Disclosures Modal */}
      {showDisclosures && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-overlay-in">
          <div className="bg-slate-900 border border-slate-700/50 rounded-2xl max-w-2xl w-full shadow-2xl animate-scale-in overflow-hidden">
            {/* Modal header with gradient accent */}
            <div className="h-1 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500" />
            <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Shield className="w-5 h-5 text-indigo-400" />
                Competition Disclosures
              </h3>
              <button
                onClick={() => setShowDisclosures(false)}
                className="text-slate-400 hover:text-white transition-colors text-lg"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-5 max-h-[65vh] overflow-y-auto">
              {/* Three improvements */}
              <div className="space-y-3">
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-300 flex items-center justify-center text-xs font-bold border border-indigo-500/30">3</span>
                  Key Improvements Delivered
                </h4>
                <div className="grid gap-2">
                  {[
                    { title: 'Auto-Contrast Token Resolver', desc: 'Maps WCAG failures to nearest approved brand swatch using CIEDE2000 color science' },
                    { title: 'Guideline Ambiguity Score (GAS)', desc: 'Mathematical telemetry separating habitual typos from contradictory guidelines' },
                    { title: 'Presidio Confidentiality Shield', desc: 'Reversible PII/codename redaction with longest-first de-anonymization' },
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-slate-950/70 border border-slate-800">
                      <span className="w-6 h-6 rounded-full bg-indigo-500/20 text-indigo-300 flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">{i + 1}</span>
                      <div>
                        <div className="text-xs font-semibold text-white">{item.title}</div>
                        <div className="text-[11px] text-slate-400 mt-0.5">{item.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Libraries */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Open-Source Libraries</h4>
                <div className="flex flex-wrap gap-1.5">
                  {['Microsoft Presidio (MIT)', 'pyahocorasick (BSD)', 'OpenCV + NumPy (Apache/BSD)', 'FastAPI + Uvicorn (MIT)', 'React 19 + Vite + Tailwind (MIT)'].map((lib) => (
                    <span key={lib} className="text-[11px] px-2 py-1 rounded-md bg-slate-950 text-slate-400 border border-slate-800">{lib}</span>
                  ))}
                </div>
              </div>

              {/* AI services */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Lock className="w-3 h-3" /> External AI Services
                </h4>
                <p className="text-[11px] text-slate-400 leading-relaxed bg-slate-950/70 p-3 rounded-lg border border-slate-800">
                  Semantic passes use Claude 3.5 Sonnet / GPT-4o with Presidio PII airlock active. Air-gapped fallback routes to local Ollama (Llama-3.1-8B-Instruct).
                </p>
              </div>
            </div>

            <div className="px-6 py-4 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setShowDisclosures(false)}
                className="px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default App;
